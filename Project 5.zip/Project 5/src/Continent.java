/**
 * Project #5
 * CS 2334 Section 012
 * April 30, 2014
 * 
 * This class extends Region class and implements Comparable.  
 * It constructs the Continent type.
 *
 */
public class Continent extends Region implements Comparable<Region>
{	
	private static final long serialVersionUID = 1L;

	public Continent(String name, String population, String area)
	{
		super(name, area, population);
	}

	public int compareTo(Continent o) 
	{
		return name.compareTo(o.name);
	}	

	public void setName(String name)
	{
		this.name = name;
	}
	
	public void setArea(String area)
	{
		this.area = area;
	}
	
	public void setPopulation(String population)
	{
		this.population = population;
	}
}