/**
 * Project #5
 * CS 2334 Section 012
 * April 30, 2014
 * 
 * This is the controller class for our Region MVC design
 *
 */

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class RegionController 
{
	 RegionModel model;
	 SelectionView view;
	 GraphView barGraph;
	 MapView map;

	public RegionController()
	{
		
	}

	public void setModel(RegionModel model) 
	{
		this.model = model;
	}
	
	public void setInputWindow(SelectionView theView) 
	{
		this.view = theView;
		this.view.getImportItem().addActionListener(new ImportListener());
		this.view.getExportItem().addActionListener(new ExportListener());
		this.view.getSaveItem().addActionListener(new SaveListener());
		this.view.getLoadItem().addActionListener(new LoadListener());
		this.view.getContItem().addActionListener(new SimpleBarContinentListener());
		this.view.getCountItem().addActionListener(new SimpleBarCountryListener());
		this.view.getCityItem().addActionListener(new SimpleBarCityListener());
		this.view.getPlaceItem().addActionListener(new SimpleBarPlacesListener());
		
		this.view.getItmCountryCont().addActionListener(new StackedBarCountContListener());
		this.view.getItmCityCountry().addActionListener(new StackedBarCityCountListener());
		this.view.getItmPlacesCont().addActionListener(new StackedBarPlaceContListener());
		this.view.getItmPlacesCount().addActionListener(new StackedBarPlaceCountListener());
		this.view.getItmPlacesCity().addActionListener(new StackedBarPlaceCityListener());
		
		this.view.getItmPopCountryCont().addActionListener(new StackedBarCountContPopListener());
		this.view.getItmPopCityCountry().addActionListener(new StackedBarCityCountPopListener());
		this.view.getItmPopPlacesCont().addActionListener(new StackedBarPlaceContPopListener());
		this.view.getItmPopPlacesCount().addActionListener(new StackedBarPlaceCountPopListener());
		this.view.getItmPopPlacesCity().addActionListener(new StackedBarPlaceCityPopListener());
		
		this.view.getContPopItem().addActionListener(new SimpleBarContinentPopListener());
		this.view.getCountPopItem().addActionListener(new SimpleBarCountryPopListener());
		this.view.getCityPopItem().addActionListener(new SimpleBarCityPopListener());
		this.view.getPlacePopItem().addActionListener(new SimpleBarPlacesPopListener());
		
		this.view.getItmPointCont().addActionListener(new MapPointContListener());
		this.view.getItmPointCount().addActionListener(new MapPointCountListener());
		this.view.getItmPointCity().addActionListener(new MapPointCityListener());
		this.view.getItmPointWorld().addActionListener(new MapPointListener());
		this.view.getItmCityWorld().addActionListener(new MapCityListener());
		this.view.getItmCityCount().addActionListener(new MapCityCountListener());
		this.view.getItmCityCont().addActionListener(new MapCityContListener());

		this.view.getContAddButton().addActionListener(new ContAddListener());
		this.view.getCountAddButton().addActionListener(new CountAddListener());
		this.view.getCityAddButton().addActionListener(new CityAddListener());
		this.view.getPlaceAddButton().addActionListener(new PlaceAddListener());
		this.view.getPointAddButton().addActionListener(new PointAddListener());
		
		this.view.getContEditButton().addActionListener(new ContEditListener());
		this.view.getCountEditButton().addActionListener(new CountEditListener());
		this.view.getCityEditButton().addActionListener(new CityEditListener());
		this.view.getPlaceEditButton().addActionListener(new PlaceEditListener());
		this.view.getPointEditButton().addActionListener(new PointEditListener());
		
		this.view.getContDeleteButton().addActionListener(new ContDeleteListener());
		this.view.getCountDeleteButton().addActionListener(new CountDeleteListener());
		this.view.getCityDeleteButton().addActionListener(new CityDeleteListener());
		this.view.getPlaceDeleteButton().addActionListener(new PlaceDeleteListener());
		this.view.getPointDeleteButton().addActionListener(new PointDeleteListener());
		
		this.view.getNeighborhoodList().addActionListener(new NeighListListener());
		this.view.getRecNeighborhoodList().addActionListener(new RecNeighListener());
		this.view.getNeighborhoodCheck().addActionListener(new NeighCheckListener());
		this.view.getNeighborhoodMap().addActionListener(new NeighMapListener());
		
		this.view.getBreadthButton().addActionListener(new BreadthListener());
		this.view.getLengthButton().addActionListener(new LengthListener());
		this.view.getLatLongButton().addActionListener(new LatLongListener());
	}
	
	public void setGraphWindow(GraphView barGraph)
	{
		this.barGraph = barGraph;
	}
	
	public void setMapWindow(MapView map)
	{
		this.map = map;
	}
	
	private class ContAddListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e) 
		{
			String cont = JOptionPane.showInputDialog("Enter a continent in the form " +
													  "Name, Area, Population");
			String[] data = cont.split(", ");
			Continent newContinent = new Continent(data[0], data[1], data[2]);
			model.addContinentList(newContinent);
		}	
	}

	private class CountAddListener implements ActionListener
	{
		@Override
		public void actionPerformed(ActionEvent e) {
		
			String count = JOptionPane.showInputDialog("Enter a country in the form " +
													   "Name, Area, Population, Continent");
			String[] data = count.split(", ");
			Country newCountry = new Country(data[0], data[1], data[2], data[3]);
			model.addCountryList(newCountry);
		}	
	}

	private class CityAddListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e) 
		{
			String city = JOptionPane.showInputDialog("Enter a city in the form " +
					    							  "Name, Area, Population, Latitude, Longitude, Elevation, Country");
			String[] data = city.split(", ");
			City newCity = new City(data[0], data[1], data[2], data[3], data[4], data[5], data[6]);
			model.addCityList(newCity);
		}
	}
	
	private class PlaceAddListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e) 
		{
			String place = JOptionPane.showInputDialog("Enter a place in the form " +
					"Name, Area, Type, Country");
			String[] data = place.split(", ");
			Place newPlace = new Place(data[0], data[1], data[2], data[3]);
			model.addPlaceList(newPlace);
		}	
	}

	private class PointAddListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e) 
		{
			String point = JOptionPane.showInputDialog("Enter a Point in the form " +
					"Name, Type, latitude, longitude, Elevation, Region");
			String[] data = point.split(", ");
			Point newPoint = new Point(data[0], data[1], data[2], data[3], data[4], data[5]);
			model.addPointList(newPoint);
		}	
	}
	
	JFrame contEditFrame = new JFrame("Edit Continent");
	JButton contEditButton = new JButton("Change");
	
	public JButton getContEditButton()
	{
		return contEditButton;
	}
	
	JTextField contName;
	JTextField contArea;
	JTextField contPopulation;
	
	private class ContEditListener implements ActionListener
	{		
		@Override
		public void actionPerformed(ActionEvent e) 
		{			
			Continent continent = (Continent) view.contList.getSelectedValue();
			
			contName = new JTextField(continent.getName());
			contArea = new JTextField(continent.getArea());
			contPopulation = new JTextField(continent.getPopulation());
			
			contEditFrame.setLayout(new GridLayout(4, 1, 5, 5));
			contEditFrame.add(contName, new GridLayout(1, 1, 5, 5));
			contEditFrame.add(contArea, new GridLayout(2, 1, 5, 5));
			contEditFrame.add(contPopulation, new GridLayout(3, 1, 5, 5));
			contEditFrame.add(contEditButton, new GridLayout(4, 1, 5, 5));
			contEditFrame.setSize(200, 200);
			contEditFrame.setVisible(true);
			
			getContEditButton().addActionListener(new ContChangeListener());
		}
	}
	
	private class ContChangeListener implements ActionListener
	{	
		public void actionPerformed(ActionEvent e) 
		{				
			Continent cont = (Continent) view.contList.getSelectedValue();
			
			String name = contName.getText();
			String area = contArea.getText();
			String population = contPopulation.getText();
			
			cont.setName(name);
			cont.setArea(area);
			cont.setPopulation(population);
			
			contEditFrame.remove(contName);
			contEditFrame.remove(contArea);
			contEditFrame.remove(contPopulation);
		}
	}
	
	JFrame countEditFrame = new JFrame("Edit Country");
	JButton countEditButton = new JButton("Change");
	
	public JButton getCountEditButton()
	{
		return countEditButton;
	}
	
	JTextField countName;
	JTextField countArea;
	JTextField countPopulation;
	JTextField countContinent;
	
	private class CountEditListener implements ActionListener
	{		
		public void actionPerformed(ActionEvent e) 
		{			
			Country country = (Country) view.countList.getSelectedValue();
			
			countName = new JTextField(country.getName());
			countArea = new JTextField(country.getArea());
			countPopulation = new JTextField(country.getPopulation());
			countContinent = new JTextField(country.getContinent());
			
			countEditFrame.setLayout(new GridLayout(5, 1, 5, 5));
			countEditFrame.add(countName, new GridLayout(1, 1, 5, 5));
			countEditFrame.add(countArea, new GridLayout(2, 1, 5, 5));
			countEditFrame.add(countPopulation, new GridLayout(3, 1, 5, 5));
			countEditFrame.add(countContinent, new GridLayout(4, 1, 5, 5));
			countEditFrame.add(countEditButton, new GridLayout(5, 1, 5, 5));
			countEditFrame.setSize(200, 200);
			countEditFrame.setVisible(true);
			
			getCountEditButton().addActionListener(new CountChangeListener());
		}
	}
	
	private class CountChangeListener implements ActionListener
	{	
		public void actionPerformed(ActionEvent e) 
		{				
			Country count = (Country) view.countList.getSelectedValue();
			
			String name = countName.getText();
			String area = countArea.getText();
			String population = countPopulation.getText();
			String continent = countContinent.getText();
			
			count.setName(name);
			count.setArea(area);
			count.setPopulation(population);
			count.setContinent(continent);
			
			countEditFrame.remove(countName);
			countEditFrame.remove(countArea);
			countEditFrame.remove(countPopulation);
			countEditFrame.remove(countContinent);
		}
	}
	
	JFrame cityEditFrame = new JFrame("Edit City");
	JButton cityEditButton = new JButton("Change");
	
	public JButton getCityEditButton()
	{
		return cityEditButton;
	}
	
	JTextField cityName;
	JTextField cityArea;
	JTextField cityPopulation;
	JTextField cityElevation;
	JTextField cityLongitude;
	JTextField cityLatitude;
	JTextField cityCountryName;
	
	private class CityEditListener implements ActionListener
	{		
		@Override
		public void actionPerformed(ActionEvent e) 
		{			
			City city = (City) view.countList.getSelectedValue();
			
			cityName = new JTextField(city.getName());
			cityArea = new JTextField(city.getArea());
			cityPopulation = new JTextField(city.getPopulation());
			cityElevation = new JTextField(city.getElevation());
			cityLongitude = new JTextField(city.getLongitude());
			cityLatitude = new JTextField(city.getLatitude());
			cityCountryName = new JTextField(city.getCountryName());
			
			cityEditFrame.setLayout(new GridLayout(8, 1, 5, 5));
			cityEditFrame.add(cityName, new GridLayout(1, 1, 5, 5));
			cityEditFrame.add(cityArea, new GridLayout(2, 1, 5, 5));
			cityEditFrame.add(cityPopulation, new GridLayout(3, 1, 5, 5));
			cityEditFrame.add(cityLongitude, new GridLayout(4, 1, 5, 5));
			cityEditFrame.add(cityLatitude, new GridLayout(5, 1, 5, 5));
			cityEditFrame.add(cityElevation, new GridLayout(6, 1, 5, 5));
			cityEditFrame.add(cityCountryName, new GridLayout(7, 1, 5, 5));
			
			cityEditFrame.add(cityEditButton, new GridLayout(8, 1, 5, 5));
			cityEditFrame.setSize(200, 200);
			cityEditFrame.setVisible(true);
			
			getCityEditButton().addActionListener(new CityChangeListener());
		}
	}
	private class CityChangeListener implements ActionListener
	{	
		public void actionPerformed(ActionEvent e) 
		{				
			City city = (City) view.cityList.getSelectedValue();
			
			String name = cityName.getText();
			String area = cityArea.getText();
			String population = cityPopulation.getText();
			String longitude = cityLongitude.getText();
			String latitude = cityLatitude.getText();
			String elevation = cityElevation.getText();
			String countryName = cityCountryName.getText();
			
			city.setName(name);
			city.setArea(area);
			city.setPopulation(population);
			city.setLongitude(longitude);
			city.setLatitude(latitude);
			city.setElevation(elevation);
			city.setCountryName(countryName);
			
			cityEditFrame.remove(cityName);
			cityEditFrame.remove(cityArea);
			cityEditFrame.remove(cityPopulation);
			cityEditFrame.remove(cityLongitude);
			cityEditFrame.remove(cityLatitude);
			cityEditFrame.remove(cityElevation);
			cityEditFrame.remove(cityCountryName);
		}
	}
	
	JFrame placeEditFrame = new JFrame("Edit Place");
	JButton placeEditButton = new JButton("Change");
	
	public JButton getPlaceEditButton()
	{
		return placeEditButton;
	}
	
	JTextField placeName;
	JTextField placeArea;
	JTextField placeType;
	JTextField placeCountryName;
	
	private class PlaceEditListener implements ActionListener
	{		
		public void actionPerformed(ActionEvent e) 
		{			
			Place place = (Place) view.placeList.getSelectedValue();
			
			placeName = new JTextField(place.getName());
			placeArea = new JTextField(place.getArea());
			placeType = new JTextField(place.getType());
			placeCountryName = new JTextField(place.getCountry());
			
			placeEditFrame.setLayout(new GridLayout(5, 1, 5, 5));
			placeEditFrame.add(placeName, new GridLayout(1, 1, 5, 5));
			placeEditFrame.add(placeArea, new GridLayout(2, 1, 5, 5));
			placeEditFrame.add(placeType, new GridLayout(3, 1, 5, 5));
			placeEditFrame.add(placeCountryName, new GridLayout(4, 1, 5, 5));
			placeEditFrame.add(placeEditButton, new GridLayout(5, 1, 5, 5));
			
			placeEditFrame.setSize(200, 200);
			placeEditFrame.setVisible(true);
			
			getPlaceEditButton().addActionListener(new PlaceChangeListener());
		}
	}
	
	private class PlaceChangeListener implements ActionListener
	{	
		public void actionPerformed(ActionEvent e) 
		{				
			Place place = (Place) view.placeList.getSelectedValue();
			
			String name = placeName.getText();
			String area = placeArea.getText();
			String type = placeType.getText();
			String countryName = placeCountryName.getText();
			
			place.setName(name);
			place.setArea(area);
			place.setType(type);
			place.setCountry(countryName);
			
			placeEditFrame.remove(placeName);
			placeEditFrame.remove(placeArea);
			placeEditFrame.remove(placeType);
			placeEditFrame.remove(placeCountryName);
		}
	}
	
	JFrame pointEditFrame = new JFrame("Edit Point");
	JButton pointEditButton = new JButton("Change");
	
	public JButton getPointEditButton()
	{
		return pointEditButton;
	}
	
	JTextField pointName;
	JTextField pointElevation;
	JTextField pointLongitude;
	JTextField pointLatitude;
	JTextField pointType;
	JTextField pointRegion;
	
	private class PointEditListener implements ActionListener
	{		
		public void actionPerformed(ActionEvent e) 
		{			
			Point point = (Point) view.pointList.getSelectedValue();
			
			pointName = new JTextField(point.getName());
			pointElevation = new JTextField(point.getElevation());
			pointLongitude = new JTextField(point.getLongitude());
			pointLatitude = new JTextField(point.getLatitude());
			pointType = new JTextField(point.getType());
			pointRegion = new JTextField(point.getRegion());
			
			pointEditFrame.setLayout(new GridLayout(7, 1, 5, 5));
			pointEditFrame.add(pointName, new GridLayout(1, 1, 5, 5));
			pointEditFrame.add(pointElevation, new GridLayout(2, 1, 5, 5));
			pointEditFrame.add(pointLongitude, new GridLayout(3, 1, 5, 5));
			pointEditFrame.add(pointLatitude, new GridLayout(4, 1, 5, 5));
			pointEditFrame.add(pointType, new GridLayout(5, 1, 5, 5));
			pointEditFrame.add(pointRegion, new GridLayout(6, 1, 5, 5));
			
			pointEditFrame.add(pointEditButton, new GridLayout(7, 1, 5, 5));
			pointEditFrame.setSize(200, 200);
			pointEditFrame.setVisible(true);
			
			getPointEditButton().addActionListener(new PointChangeListener());
		}
	}
	private class PointChangeListener implements ActionListener
	{	
		public void actionPerformed(ActionEvent e) 
		{				
			Point point = (Point) view.pointList.getSelectedValue();
			
			String name = pointName.getText();
			String longitude = pointLongitude.getText();
			String latitude = pointLatitude.getText();
			String elevation = pointElevation.getText();
			String type = pointType.getText();
			String region = pointRegion.getText();
			
			point.setName(name);
			point.setLongitude(longitude);
			point.setLatitude(latitude);
			point.setElevation(elevation);
			point.setType(type);
			point.setRegion(region);
			
			pointEditFrame.remove(pointName);
			pointEditFrame.remove(pointLongitude);
			pointEditFrame.remove(pointLatitude);
			pointEditFrame.remove(pointElevation);
			pointEditFrame.remove(pointType);
			pointEditFrame.remove(pointRegion);
		}
	}
	
	private class PointDeleteListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e) {
		
			Point point =  (Point) view.pointList.getSelectedValue();
			model.deletePointList(point);
		}
	}
	
	private class PlaceDeleteListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e) 
		{
			Place place =  (Place) view.placeList.getSelectedValue();
			model.deletePlaceList(place);
		}
		
	}
	
	private class CityDeleteListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e) 
		{
			City count =  (City) view.cityList.getSelectedValue();
			model.deleteCityList(count);		
		}
	}
	
	private class CountDeleteListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e) 
		{
			Country count =  (Country) view.countList.getSelectedValue();
			model.deleteCountryList(count);
		}
	}
	
	private class ContDeleteListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e) 
		{
			Continent cont = (Continent) view.contList.getSelectedValue();
			model.deleteContinentList(cont);
		}
	}

	class SimpleBarContinentListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e) 
		{
			List<Continent> cont =  view.contList.getSelectedValuesList();
			
			long[] data = new long[cont.size()];
			String[] names = new String[cont.size()];
			
			for (int i =0; i < cont.size(); i ++)
			{
				String[] areas = new String[cont.size()];
				names[i] = cont.get(i).getName();
				areas[i] = cont.get(i).getArea();
				data[i] = Long.parseLong(areas[i]);				
            }
			GraphView barGraph = new GraphView();
			JFrame graphFrame = new JFrame();
			graphFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);
			barGraph.showHistogram(data, names);
			graphFrame.add(barGraph);
			graphFrame.setVisible(true);
		}
	}
	
	class SimpleBarCountryListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e) 
		{
			List<Country> count =  view.countList.getSelectedValuesList();
			long[] data = new long[count.size()];
			String[] names = new String[count.size()];
			
			for (int i =0; i < count.size(); i++)
			{
				String[] areas = new String[count.size()];
				names[i] = count.get(i).getName();
				areas[i] = count.get(i).getArea();
				data[i] = Long.parseLong(areas[i]);
			}	
			
			GraphView barGraph = new GraphView();
			JFrame graphFrame = new JFrame();
			graphFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);
			barGraph.showHistogram(data, names);
			graphFrame.add(barGraph);
			graphFrame.setVisible(true);
		}
	}
	
	class SimpleBarCityListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e) 
		{
			List<City> city =  view.cityList.getSelectedValuesList();
			long[] data = new long[city.size()];
			String[] names = new String[city.size()];
			
			for (int i =0; i < city.size(); i++)
			{
				String[] areas = new String[city.size()];
				names[i] = city.get(i).getName();
				areas[i] = city.get(i).getArea();
				data[i] = Long.parseLong(areas[i]);
			}
			
			GraphView barGraph = new GraphView();
			JFrame graphFrame = new JFrame();
			graphFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);
			barGraph.showHistogram(data, names);
			graphFrame.add(barGraph);
			graphFrame.setVisible(true);	
		}
	}
	
	class SimpleBarPlacesListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e) 
		{
			List<Place> place =  view.placeList.getSelectedValuesList();
			long[] data = new long[place.size()];
			String[] names = new String[place.size()];
			
			for (int i =0; i < place.size(); i++) 
			{
				String[] areas = new String[place.size()];
				names[i] = place.get(i).getName();
				areas[i] = place.get(i).getArea();
				data[i] = Long.parseLong(areas[i]);
			}	
			
			GraphView barGraph = new GraphView();
			JFrame graphFrame = new JFrame();
			graphFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);
			barGraph.showHistogram(data, names);
			graphFrame.add(barGraph);
			graphFrame.setVisible(true);
		}
	}
	
	class SimpleBarContinentPopListener implements ActionListener
	{
		public void actionPerformed(ActionEvent arg0) 
		{
			List<Continent> cont =  view.contList.getSelectedValuesList();
			long[] data = new long[cont.size()];
			String[] names = new String[cont.size()];
			
			for (int i =0; i < cont.size(); i++)
			{
				String[] pop = new String[cont.size()];
				names[i] = cont.get(i).getName();
				pop[i] = cont.get(i).getPopulation();
				data[i] = Long.parseLong(pop[i]);
			}	
			
			GraphView barGraph = new GraphView();
			JFrame graphFrame = new JFrame();
			graphFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);
			barGraph.showHistogram(data, names);
			graphFrame.add(barGraph);
			graphFrame.setVisible(true);
		}
	} 
	
	class SimpleBarCountryPopListener implements ActionListener
	{
		public void actionPerformed(ActionEvent arg0) 
		{
			List<Country> count =  view.countList.getSelectedValuesList();
			long[] data = new long[count.size()];
			String[] names = new String[count.size()];
			
			for (int i =0; i < count.size(); i++)
			{
				String[] pop = new String[count.size()];
				names[i] = count.get(i).getName();
				pop[i] = count.get(i).getPopulation();
				data[i] = Long.parseLong(pop[i]);
			}	
			
			GraphView barGraph = new GraphView();
			JFrame graphFrame = new JFrame();
			graphFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);
			barGraph.showHistogram(data, names);
			graphFrame.add(barGraph);
			graphFrame.setVisible(true);	
		}
		
	}
	class SimpleBarCityPopListener implements ActionListener
	{
		public void actionPerformed(ActionEvent arg0) 
		{
			List<City> city =  view.cityList.getSelectedValuesList();
			long[] data = new long[city.size()];
			String[] names = new String[city.size()];
			
			for(int i =0; i < city.size(); i++)
			{
				String[] pop = new String[city.size()];
				names[i] = city.get(i).getName();
				pop[i] = city.get(i).getPopulation();
				data[i] = Long.parseLong(pop[i]);
			}	
			
			GraphView barGraph = new GraphView();
			JFrame graphFrame = new JFrame();
			graphFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);
			barGraph.showHistogram(data, names);
			graphFrame.add(barGraph);
			graphFrame.setVisible(true);
		}
	}
	
	class SimpleBarPlacesPopListener implements ActionListener
	{
		public void actionPerformed(ActionEvent arg0) 
		{
			List<Place> place =  view.placeList.getSelectedValuesList();
			long[] data = new long[place.size()];
			String[] names = new String[place.size()];
			
			for (int i =0; i < place.size(); i++)
			{
				String[] pop = new String[place.size()];
				names[i] = place.get(i).getName();
				pop[i] = place.get(i).getPopulation();
				data[i] = Long.parseLong(pop[i]);
			}	
			
			GraphView barGraph = new GraphView();
			JFrame graphFrame = new JFrame();
			graphFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);
			barGraph.showHistogram(data, names);
			graphFrame.add(barGraph);
			graphFrame.setVisible(true);
		}
	}
	
	class StackedBarCountContListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e) 
		{
			List<Country> count = view.countList.getSelectedValuesList();
			Continent cont = (Continent) view.contList.getSelectedValue();
			List<Country> match = new ArrayList<Country>();
			
			for (int i = 0; i<count.size(); i++)
			{
				if(count.get(i).getContinent().equals(cont.getName()))
				{
					match.add(count.get(i));
				}
			}
			
			long[] data = new long[match.size()];
			String[] names = new String[match.size()];
			
			for (int k = 0; k < match.size(); k++)
			{
				data[k] = Long.parseLong(match.get(k).getArea());
				names[k] = match.get(k).getName();
			}
			
			StackedGraphView stackGraph = new StackedGraphView();
			JFrame stackFrame = new JFrame();
			stackFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);
			stackGraph.showHistogram(data, names);
			stackFrame.add(stackGraph);
			stackFrame.setVisible(true);	
		}
	}
	
	class StackedBarCityCountListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e) 
		{
			List<City> city = view.cityList.getSelectedValuesList();
			Country count = (Country) view.countList.getSelectedValue();
			List<City> match = new ArrayList<City>();
			
			for (int i = 0; i<city.size(); i++)
			{
				if(city.get(i).getCountryName().equals(count.getName()))
				{
					match.add(city.get(i));
				}
			}
			
			long[] data = new long[match.size()];
			String[] names = new String[match.size()];
			
			for(int k = 0; k < match.size(); k++)
			{
				data[k] = Long.parseLong(match.get(k).getArea());
				names[k] = match.get(k).getName();
			}
			
			StackedGraphView stackGraph = new StackedGraphView();
			JFrame stackFrame = new JFrame();
			stackFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);
			stackGraph.showHistogram(data, names);
			stackFrame.add(stackGraph);
			stackFrame.setVisible(true);
		}
	}

	class StackedBarPlaceContListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e) 
		{	

		}	
	}
	
	class StackedBarPlaceCountListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e) 
		{
			List<Place> place = view.placeList.getSelectedValuesList();
			Country count = (Country) view.countList.getSelectedValue();
			List<Place> match = new ArrayList<Place>();
			
			for (int i = 0; i<place.size(); i++)
			{
				if (place.get(i).getCountry().equals(count.getName()))
				{
					match.add(place.get(i));
				}
			}
			
			long[] data = new long[match.size()];
			String[] names = new String[match.size()];
			
			for (int k = 0; k < match.size(); k++)
			{
				data[k] = Long.parseLong(match.get(k).getArea());
				names[k] = match.get(k).getName();
			}
			
			StackedGraphView stackGraph = new StackedGraphView();
			JFrame stackFrame = new JFrame();
			stackFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);
			stackGraph.showHistogram(data, names);
			stackFrame.add(stackGraph);
			stackFrame.setVisible(true);
		}	
	}
	
	class StackedBarPlaceCityListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e) {
	
		}	
	}
	
	class StackedBarCountContPopListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e) 
		{
			List<Country> count = view.countList.getSelectedValuesList();
			Continent cont = (Continent) view.contList.getSelectedValue();
			List<Country> match = new ArrayList<Country>();
			
			for (int i = 0; i<count.size(); i++)
			{
				if (count.get(i).getContinent().equals(cont.getName()))
				{
					match.add(count.get(i));
				}
			}
			
			long[] data = new long[match.size()];
			String[] names = new String[match.size()];
			
			for (int k = 0; k < match.size(); k++)
			{
				data[k] = Long.parseLong(match.get(k).getPopulation());
				names[k] = match.get(k).getName();
			}
			
			StackedGraphView stackGraph = new StackedGraphView();
			JFrame stackFrame = new JFrame();
			stackFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);
			stackGraph.showHistogram(data, names);
			stackFrame.add(stackGraph);
			stackFrame.setVisible(true);
		}
	}
	
	class StackedBarCityCountPopListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e) 
		{
			List<City> city = view.cityList.getSelectedValuesList();
			Country count = (Country) view.countList.getSelectedValue();
			List<City> match = new ArrayList<City>();
			
			for (int i = 0; i<city.size(); i++)
			{
				if (city.get(i).getCountryName().equals(count.getName()))
				{
					match.add(city.get(i));
				}
			}
			
			long[] data = new long[match.size()];
			String[] names = new String[match.size()];
			
			for (int k = 0; k < match.size(); k++)
			{
				data[k] = Long.parseLong(match.get(k).getPopulation());
				names[k] = match.get(k).getName();
			}
			
			StackedGraphView stackGraph = new StackedGraphView();
			JFrame stackFrame = new JFrame();
			stackFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);
			stackGraph.showHistogram(data, names);
			stackFrame.add(stackGraph);
			stackFrame.setVisible(true);
		}
	}
	
	class StackedBarPlaceContPopListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e) 
		{
			
		}	
	}
	
	class StackedBarPlaceCountPopListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e) 
		{
			List<Place> place = view.placeList.getSelectedValuesList();
			Country count = (Country) view.countList.getSelectedValue();
			List<Place> match = new ArrayList<Place>();
			
			for(int i = 0; i<place.size(); i++)
			{
				if(place.get(i).getCountry().equals(count.getName()))
				{
					match.add(place.get(i));
				}
			}
			
			long[] data = new long[match.size()];
			String[] names = new String[match.size()];
			
			for(int k = 0; k < match.size(); k++)
			{
				data[k] = Long.parseLong(match.get(k).getPopulation());
				names[k] = match.get(k).getName();
			}
			
			StackedGraphView stackGraph = new StackedGraphView();
			JFrame stackFrame = new JFrame();
			stackFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);
			stackGraph.showHistogram(data, names);
			stackFrame.add(stackGraph);
			stackFrame.setVisible(true);
		}	
	}
	
	class StackedBarPlaceCityPopListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e) {
			
		}	
	}
	
	class MapCityContListener implements ActionListener 
	{
		public void actionPerformed(ActionEvent e) 
		{
			List<City> city = view.cityList.getSelectedValuesList();
			Continent cont = (Continent) view.contList.getSelectedValue();
			List<Country> country = (List<Country>) view.countList;
			List<Continent> continent = (List<Continent>) view.contList;
			ArrayList<Country> objects = new ArrayList<Country>();
			ArrayList<Country> match = new ArrayList<Country>();
			String[] countName = new String[city.size()];
			ArrayList<City> wantedCity = new ArrayList<City>();
			
			for (int i=0; i<city.size(); i++)
			{
				countName[i] = city.get(i).getCountryName();
			}
			
			for (int j = 0; j<country.size(); j++)
			{ 
				if(country.get(j).getName().equals(countName[j]))
				{
					objects.add(country.get(j));
				}
			}
			
			for (int k = 0; k < objects.size(); k++)
			{
				if(objects.get(k).getContinent().equals(cont.getName()))
				{
						match.add(objects.get(k));
				}
			}
			
			for (int i = 0; i < match.size(); i++)
			{
				if (city.get(i).getCountryName().equals(match.get(i).getName()))
				{
					wantedCity.add(city.get(i));
				}
			}
			
			String[] latDataString = new String[wantedCity.size()];
			String[] longDataString = new String[wantedCity.size()];
			double[] latData = new double[wantedCity.size()];
			double[] longData = new double[wantedCity.size()];
			
			for (int i = 0; i<wantedCity.size(); i++)
			{
				latDataString[i] = wantedCity.get(i).getLatitude();
				longDataString[i] = wantedCity.get(i).getLongitude();
				
				if (latDataString[i].contains("N"))
				{
					String sub = latDataString[i].substring(1);
					latData[i] = Double.parseDouble(sub);
					latData[i] = 90.0 - latData[i];
				}
				
				if (latDataString[i].contains("S"))
				{
					String sub = latDataString[i].substring(1);
					latData[i] = Double.parseDouble(sub);
					latData[i] = 90.0 + latData[i];
				}
				
				if (longDataString[i].contains("E"))
				{
					String sub = longDataString[i].substring(1);
					longData[i] = Double.parseDouble(sub);
					longData[i] = longData[i] + 180.0;
				}
				
				if (longDataString[i].contains("W"))
				{
					String sub = longDataString[i].substring(1);
					longData[i] = Double.parseDouble(sub);
					longData[i] = 180.0 - longData[i];
				}
			}
			
			MapView map = new MapView();
			JFrame mapFrame = new JFrame();
			mapFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);
			map.showMap(latData, longData);
			mapFrame.add(map);
			mapFrame.setVisible(true);
		}
	}
	
	class MapCityCountListener implements ActionListener 
	{
		public void actionPerformed(ActionEvent e) {

		}
	}
	
	class MapCityListener implements ActionListener 
	{
		public void actionPerformed(ActionEvent e) 
		{
			List<City> city = view.cityList.getSelectedValuesList();
			
			String[] latDataString = new String[city.size()];
			String[] longDataString = new String[city.size()];
			
			double[] latData = new double[city.size()];
			double[] longData = new double[city.size()];
			
			for(int i = 0; i<city.size(); i++)
			{
				latDataString[i] = city.get(i).getLatitude();
				longDataString[i] = city.get(i).getLongitude();
				
					if (latDataString[i].contains("N"))
					{
						String sub = latDataString[i].substring(1);
						latData[i] = Double.parseDouble(sub);
						latData[i] = 90.0 - latData[i];
					}
					if (latDataString[i].contains("S"))
					{
						String sub = latDataString[i].substring(1);
						latData[i] = Double.parseDouble(sub);
						latData[i] = 90.0 + latData[i];
					}
					if (longDataString[i].contains("E"))
					{
						String sub = longDataString[i].substring(1);
						longData[i] = Double.parseDouble(sub);
						longData[i] = longData[i] + 180.0;
					}
					if (longDataString[i].contains("W"))
					{
						String sub = longDataString[i].substring(1);
						longData[i] = Double.parseDouble(sub);
						longData[i] = 180.0 - longData[i];
					}
					else 
						System.out.println("No location available.");
			}
			
			MapView map = new MapView();
			JFrame mapFrame = new JFrame();
			mapFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);
			map.showMap(latData, longData);
			mapFrame.add(map);
			mapFrame.setVisible(true);
		}
	}
	class MapPointCityListener implements ActionListener 
	{
		public void actionPerformed(ActionEvent e) {
			
		}
	}
	
	class MapPointCountListener implements ActionListener 
	{
		public void actionPerformed(ActionEvent e) {
			
		}
	}
	
	class MapPointContListener implements ActionListener 
	{
		public void actionPerformed(ActionEvent e) {
			
		}
	}
	
	class MapPointListener implements ActionListener 
	{
		public void actionPerformed(ActionEvent e) {
			
		}
	}

	class ExportListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e) 
		{	
			try {
				model.writeTextFile();
			} catch (IOException e1) {
				System.out.println("Cannot write to text file.");
			}
		}
	}
	
	class SaveListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e) {

			String choice =JOptionPane.showInputDialog("Which list write to binary file?" +
														"\n" + "1 - Continent" +
														"\n" + "2 - Country" +
														"\n" + "3 - City" +
														"\n" + "4 - Place" +
														"\n" + "5 - Point");
			if (choice.equals("1"))
			{
				try {
				model.writeBinaryFile(model.continentList);	
				} catch (IOException e1) {
				e1.printStackTrace();
				}
			}
			
			if (choice.equals("2"))
			{
				try {
					model.writeBinaryFile(model.countryList);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
			if (choice.equals("3"))
			{
				try {
					model.writeBinaryFile(model.cityList);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
			if (choice.equals("4"))
			{
				try {
					model.writeBinaryFile(model.placeList);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
			if (choice.equals("5"))
			{
				try {
					model.writeBinaryFile(model.pointList);
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}		
		}
	}
	
	class LoadListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e) 
		{
			try {
				model.loadBinaryFile();
			} catch (ClassNotFoundException e1) {
				e1.printStackTrace();
			} catch (IOException e1) {
				e1.printStackTrace();
			}	
		}
	}
	
	private class ImportListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e) 
		{	
			try {
				model.importTextFile();
			} catch (IOException e1){
				e1.printStackTrace();
			}
		}
	}
	
	/**
	 * This class import the appropriate coordinate regions,
	 * and adds to the neighborhood list in the view.
	 *
	 */
	private class NeighListListener implements ActionListener
	{
		public void actionPerformed(ActionEvent arg0) 
		{	
			try {
				model.importNeighborhood();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	JButton enterBreadth = new JButton("Enter");
	JTextField breadthLat = new JTextField(5);
	public JButton getEnterBreadth()
	{
		return enterBreadth;
	}
		
	/**
	 * This class requests breadth from the user.
	 *
	 */
	private class BreadthListener implements ActionListener
	{
		public void actionPerformed(ActionEvent arg0) 
		{	
			JFrame breadthFrame = new JFrame("Breadth");
			JPanel breadthPanel = new JPanel();
			
			breadthPanel.setLayout(new GridLayout(1, 2, 5, 5));
			breadthPanel.add(new JLabel("Breadth: "), new GridLayout(1, 2, 5, 5));
			breadthPanel.add(breadthLat, new GridLayout(1, 2, 5, 5));
			
			breadthFrame.add(new JLabel("Enter breadth ONLY: "), BorderLayout.NORTH);
			breadthFrame.add(breadthPanel, BorderLayout.CENTER);
			breadthFrame.add(enterBreadth, BorderLayout.SOUTH);
			breadthFrame.setSize(200, 150);
			breadthFrame.setLocationRelativeTo(null);
			breadthFrame.setVisible(true);
			
			getEnterBreadth().addActionListener(new BreadthEnterListener());
		}
	}
	
	/**
	 * This class takes in the breadth from the user
	 * and searches appropriate neighboring areas according to the breadth.
	 *
	 */
	private class BreadthEnterListener implements ActionListener
	{
		public void actionPerformed(ActionEvent arg0) 
		{
			HashSet<Neighborhood> nLat = new HashSet<Neighborhood>();
			HashSet<Neighborhood> nLong = new HashSet<Neighborhood>();
			Neighborhood selectedNeighborhood =  (Neighborhood) view.neighborhoodList.getSelectedValue();
			double selectedLatitude = selectedNeighborhood.getNLatitude();
			double breadth = Double.parseDouble(breadthLat.getText());
			
			for (int i = 0; i < model.neighborhoodList.size(); i++)
			{
				double cLatitude = model.neighborhoodList.get(i).getNLatitude();		
				if (Math.abs(cLatitude - selectedLatitude) < breadth)
				{
					String name = model.neighborhoodList.get(i).getName();
					String latitude = model.neighborhoodList.get(i).getLatitude();
					String longitude = model.neighborhoodList.get(i).getLongitude();
					
					Neighborhood latNeighborhood = new Neighborhood(name, latitude, longitude);
					nLat.add(latNeighborhood);
					
					System.out.println(name + " " + latitude + " " + longitude);
				}
			}
		}
	}
	
	JButton enterLength = new JButton("Enter");
	JTextField lengthLong = new JTextField(5);
	public JButton getEnterLength()
	{
		return enterLength;
	}
	
	/**
	 * This class requests length from the user.
	 *
	 */
	private class LengthListener implements ActionListener
	{
		public void actionPerformed(ActionEvent arg0) 
		{	
			JFrame lengthFrame = new JFrame("");
			JPanel lengthPanel = new JPanel();
			
			Neighborhood neighborhood = (Neighborhood) view.neighborhoodList.getSelectedValue();
			
			lengthPanel.setLayout(new GridLayout(1, 2, 5, 5));
			lengthPanel.add(new JLabel("Length: "), new GridLayout(1, 2, 5, 5));
			lengthPanel.add(lengthLong, new GridLayout(1, 2, 5, 5));
			
			lengthFrame.add(new JLabel("Enter length ONLY: "), BorderLayout.NORTH);
			lengthFrame.add(lengthPanel, BorderLayout.CENTER);
			lengthFrame.add(enterLength, BorderLayout.SOUTH);
			lengthFrame.setSize(200, 150);
			lengthFrame.setLocationRelativeTo(null);
			lengthFrame.setVisible(true);
			
			getEnterLength().addActionListener(new LengthEnterListener());
		}
	}
	
	/**
	 * This class takes in the length from the user
	 * and searches appropriate neighboring areas according to the length.
	 *
	 */
	private class LengthEnterListener implements ActionListener
	{
		public void actionPerformed(ActionEvent arg0) 
		{	
			HashSet<Neighborhood> nLong = new HashSet<Neighborhood>();
			Neighborhood selectedNeighborhood =  (Neighborhood) view.neighborhoodList.getSelectedValue();
			double selectedLongitude = selectedNeighborhood.getNLongitude();
			double length = Double.parseDouble(lengthLong.getText());
			
			for (int i = 0; i < model.neighborhoodList.size(); i++)
			{
				double cLongitude = model.neighborhoodList.get(i).getNLongitude();		
				if (Math.abs(cLongitude - selectedLongitude) < length)
				{
					String name = model.neighborhoodList.get(i).getName();
					String latitude = model.neighborhoodList.get(i).getLatitude();
					String longitude = model.neighborhoodList.get(i).getLongitude();
					
					Neighborhood longNeighborhood = new Neighborhood(name, latitude, longitude);
					nLong.add(longNeighborhood);
					
					System.out.println(name + " " + latitude + " " + longitude);
				}
			}
		}
	}
	
	JButton enterLatLong = new JButton("Enter");
	JTextField latLongLat = new JTextField(5);;
	JTextField latLongLong = new JTextField(5);
	
	public JButton getEnterLatLong()
	{
		return enterLatLong;
	}
	
	/**
	 * This class requests breadth and length from the user.
	 *
	 */
	private class LatLongListener implements ActionListener
	{
		public void actionPerformed(ActionEvent arg0) 
		{	
			JFrame latLongFrame = new JFrame("");
			JPanel latLongPanel = new JPanel();
						
			latLongPanel.setLayout(new GridLayout(2, 2, 5, 5));
			latLongPanel.add(new JLabel("Breadth: "), new GridLayout(1, 1, 1, 1));
			latLongPanel.add(latLongLat, new GridLayout(1, 2, 5, 5));
			latLongPanel.add(new JLabel("Length: "), new GridLayout(2, 1, 1, 1));
			latLongPanel.add(latLongLong, new GridLayout(2, 2, 5, 5));
			
			latLongFrame.add(new JLabel("Enter breadth and length."), BorderLayout.NORTH);
			latLongFrame.add(latLongPanel, BorderLayout.CENTER);
			latLongFrame.add(enterLatLong, BorderLayout.SOUTH);
			latLongFrame.setSize(200, 150);
			latLongFrame.setLocationRelativeTo(null);
			latLongFrame.setVisible(true);
			
			getEnterLatLong().addActionListener(new LatLongEnterListener());
		}
	}
	
	/**
	 * This class takes in the breadth and length from the user
	 * and searches appropriate neighboring areas according to the breadth and length.
	 *
	 */
	private class LatLongEnterListener implements ActionListener
	{
		public void actionPerformed(ActionEvent arg0) 
		{
			HashSet<Neighborhood> nLatLong = new HashSet<Neighborhood>();
			Neighborhood selectedNeighborhood =  (Neighborhood) view.neighborhoodList.getSelectedValue();
			double selectedLatitude = selectedNeighborhood.getNLatitude();
			double breadth = Double.parseDouble(latLongLat.getText());
			double selectedLongitude = selectedNeighborhood.getNLongitude();
			double length = Double.parseDouble(latLongLong.getText());
			
			for (int i = 0; i < model.neighborhoodList.size(); i++)
			{
				double cLatitude = model.neighborhoodList.get(i).getNLatitude();	
				double cLongitude = model.neighborhoodList.get(i).getNLatitude();
				if ( (Math.abs(cLatitude - selectedLatitude) < breadth) && (Math.abs(cLongitude - selectedLongitude) < length) )
				{
					String name = model.neighborhoodList.get(i).getName();
					String latitude = model.neighborhoodList.get(i).getLatitude();
					String longitude = model.neighborhoodList.get(i).getLongitude();
					
					Neighborhood latLongNeighborhood = new Neighborhood(name, latitude, longitude);
					nLatLong.add(latLongNeighborhood);
					
					System.out.println(name + " " + latitude + " " + longitude);
				}
			}
		}
	}
	/**
	 * This class recursively finds the neighborhood.
	 *
	 */
	private class RecNeighListener implements ActionListener
	{
		public void actionPerformed(ActionEvent e) 
		{
			HashSet<Neighborhood> rLat = new HashSet<Neighborhood>();
			Neighborhood selectedNeighborhood =  (Neighborhood) view.neighborhoodList.getSelectedValue();
			double selectedLatitude = selectedNeighborhood.getNLatitude();
			double breadth = Double.parseDouble(breadthLat.getText());
			
			for (int i = 0; i < model.neighborhoodList.size(); i++)
			{
				double cLatitude = model.neighborhoodList.get(i).getNLatitude();		
				if (Math.abs(cLatitude - selectedLatitude) < breadth)
				{
					String name = model.neighborhoodList.get(i).getName();
					String latitude = model.neighborhoodList.get(i).getLatitude();
					String longitude = model.neighborhoodList.get(i).getLongitude();
					
					Neighborhood latNeighborhood = new Neighborhood(name, latitude, longitude);
					rLat.add(latNeighborhood);
					
					System.out.println(name + " " + latitude + " " + longitude);
				}
			}
		}
	}
	
	private class NeighCheckListener implements ActionListener
	{
		public void actionPerformed(ActionEvent arg0) 
		{
			List<Neighborhood> neighList = view.neighborhoodList.getSelectedValuesList();
			getEnterBreadth().addActionListener(new BreadthEnterListener());
			getEnterLength().addActionListener(new LengthEnterListener());
			getEnterLatLong().addActionListener(new LatLongEnterListener());
		}
	}
	
	private class NeighMapListener implements ActionListener
	{
		public void actionPerformed(ActionEvent arg0) 
		{
			getEnterLatLong();
		}
	}
}