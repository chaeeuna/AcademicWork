/**
 * Project #5
 * CS 2334 Section 012
 * April 30, 2014
 * 
 * This is the class that is used to represent points of interest objects.
 * 
 */
public class Point {
	
	 String name;
	 String type;
	String latitude;
	 String longitude;
	 String elevation;
	 String region;
	
	/**
	 * Constructor for ease of use
	 */
	public Point()
	{
		
	}
	
	public Point(String name, String type, String latitude, String longitude, String elevation, String region)
	{
		this.name = name;
		this.type = type;
		this.latitude = latitude;
		this.longitude = longitude;
		this.elevation = elevation;
		this.region = region;
	}
	
	public Point(String name, String latitude, String longitude)
	{
		this.name = name;
		this.latitude = latitude;
		this.longitude = longitude;
	}
	
	public String getName()
	{
		return name;
	}
	
	public String getType()
	{
		return type;
	}
	
	public String getRegion()
	{
		return region;
	}
	
	public String getLatitude()
	{
		return latitude;
	}
	/**
	 * 
	 * @return longitude
	 */
	public String getLongitude()
	{
		return longitude;
	}
	/**
	 * 
	 * @return elevation
	 */
	public String getElevation()
	{
		return elevation;
	}
	
	public void setName(String name)
	{
		this.name = name;
	}
	
	public void setType(String type)
	{
		this.type = type;
	}
	
	public void setLatitude(String latitude)
	{
		this.latitude = latitude;
	}
	
	public void setLongitude(String longitude)
	{
		this.longitude = longitude;
	}
	
	public void setElevation(String elevation)
	{
		this.elevation = elevation;
	}
	
	public void setRegion(String region)
	{
		this.region = region;
	}
}
