/**
 * Project #5
 * CS 2334 Section 012
 * April 30, 2014
 */

import java.util.ArrayList;
import java.util.List;
import java.util.HashSet;

public class Neighborhood extends Earth
{	
	public double nLatitude;
	public double nLongitude;
	public Neighborhood()
	{
		
	}
	
	/**
	 * Constructor for the neighborhoods.
	 * @param name
	 * @param latitude
	 * @param longitude
	 */
	public Neighborhood(String name, String latitude, String longitude)
	{
		super(name, latitude, longitude);
	}
	
	/**
	 * This method takes in the latitude as a string
	 * and parses the latitude for the calculation and comparison.
	 * @return nLatitude
	 */
	public double getNLatitude()
	{
		if (getLatitude().contains("N"))
		{
			String sub = getLatitude().substring(1);
			nLatitude = Double.parseDouble(sub);
			nLatitude = 90.0 - nLatitude;
		}
		
		if (getLatitude().contains("S"))
		{
			String sub = getLatitude().substring(1);
			nLatitude = Double.parseDouble(sub);
			nLatitude = 90.0 + nLatitude;
		}
		
		return nLatitude;
	}
	
	/**
	 * This method takes in the longitude as a string
	 * and parses the longitude for the calculation and comparison.
	 * @return nLongitude
	 */
	public double getNLongitude()
	{
		if (getLongitude().contains("E"))
		{
			String sub = getLongitude().substring(1);
			nLongitude = Double.parseDouble(sub);
			nLongitude = nLongitude + 180.0;
		}
		
		if (getLongitude().contains("W"))
		{
			String sub = getLongitude().substring(1);
			nLongitude = Double.parseDouble(sub);
			nLongitude = 180.0 - nLongitude;
		}
		
		return nLongitude;
	}
}