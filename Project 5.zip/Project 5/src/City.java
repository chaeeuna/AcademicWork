/**
 * Project #5
 * CS 2334 Section 012
 * April 30, 2014
 * 
 * This class extends Region class and implements Comparable.  
 * It constructs the City type.
 * 
 */
public class City extends Region implements Comparable<Region>
{
	private static final long serialVersionUID = 1L;
	public String countryName;
	public String latitude;
	public String longitude;
	public String elevation;
	
	/**
	 * This constructor is for the cities with elevation and references. 
	 * @param name
	 * @param area
	 * @param population
	 * @param countryName
	 * @param latitude
	 * @param longitude
	 * @param elevation
	 */
	
	public City(String name, String area, String population, String countryName, String latitude, String longitude, String elevation)
	{
		super(name, area, population);
		this.countryName = countryName;
		this.latitude = latitude;
		this.longitude = longitude;
		this.elevation = elevation;
	}
	
	/**
	 * 
	 * @param name
	 * @param population
	 * @param area
	 * @param countryName
	 */
	public City(String name, String population, String area, String countryName)
	{
		super(name, area, population);
		this.countryName = countryName;
	}
	
	public City(String name, String latitude, String longitude)
	{
		this.name = name;
		this.latitude = latitude;
		this.longitude = longitude;
	}
	
	/**
	 * @return countryName
	 */
	public String getCountryName()
	{
		return countryName;
	}
	
	/**
	 * @return latitude
	 */
	public String getLatitude()
	{
		return latitude;
	}
	/**
	 * 
	 * @return longitude
	 */
	public String getLongitude()
	{
		return longitude;
	}
	/**
	 * 
	 * @return elevation
	 */
	public String getElevation()
	{
		return elevation;
	}

	public int compareTo(City obj)
	{
		return name.compareTo(obj.name);	
	}
	
	public void setName(String name)
	{
		this.name = name;
	}
	
	public void setArea(String area)
	{
		this.area = area;
	}
	
	public void setPopulation(String population)
	{
		this.population = population;
	}
	
	public void setLatitude(String latitude)
	{
		this.latitude = latitude;
	}
	
	public void setLongitude(String longitude)
	{
		this.longitude = longitude;
	}
	
	public void setElevation(String elevation)
	{
		this.elevation = elevation;
	}
	
	public void setCountryName(String countryName)
	{
		this.countryName = countryName;
	}
	
}