import java.io.Serializable;
import java.util.Comparator;

/**
 * Project #5
 * CS 2334 Section 012
 * April 30, 2014
 * 
 * This class is the superclass for all the regions and implements Comparable.
 * All static Comparator methods are created here.
 *
 */
public class Region extends Earth implements Comparable<Region>, Serializable
{	
	private static final long serialVersionUID = 1L;
	public String name;
	public String area;
	public String population;
	
	public Region()
	{
		
	}
	public static Comparator<Region> NameComparator = new Comparator<Region>()
	{
		public int compare(Region name1, Region name2)
		{
			String nameValue1 = name1.getName();
			String nameValue2 = name2.getName();
			
			if (nameValue1.compareTo(nameValue2) == -1)
			{
				return -1;
			}
			if (nameValue1.compareTo(nameValue2) == 1)
			{
				return 1;
			}
			else
			{
				return 0;
			}	
		}
	};

	public static Comparator<Region> PlaceComparator = new Comparator<Region>()
	{
		public int compare(Region area1, Region area2)
		{
			String areaValue1 = area1.getArea();
			String areaValue2 = area2.getArea();
			
			if (Integer.parseInt(areaValue1) > Integer.parseInt(areaValue2))
			{
				return -1;
			}
			
			if (Integer.parseInt(areaValue1) < Integer.parseInt(areaValue2))
			{
				return 1;
			}
			
			else return 0;
		}
	};

	public static Comparator<Region> AreaComparator = new Comparator<Region>()
	{
		public int compare(Region area1, Region area2)
		{
			String areaValue1 = area1.getArea();
			String areaValue2 = area2.getArea();
			
			if (Integer.parseInt(areaValue1) > Integer.parseInt(areaValue2))
			{
				return -1;
			}
			
			if (Integer.parseInt(areaValue1) < Integer.parseInt(areaValue2))
			{
				return 1;
			}
			
			else return 0;
		}
	};
	
	public static Comparator<Region> PopulationComparator = new Comparator<Region>()
	{	
		public int compare(Region population1, Region population2)
		{
			String popValue1 = population1.getPopulation();
			String popValue2 = population2.getPopulation();
			
			if (Long.parseLong(popValue1) > Long.parseLong(popValue2))
			{
				return -1;
			}
			
			if (Long.parseLong(popValue1) < Long.parseLong(popValue2))
			{
				return 1;
			}
			
			else return 0;
		}
	};
	
	public static Comparator<City> LatitudeComparator = new Comparator<City>()
	{
		public int compare(City latitude1, City latitude2)
		{
			String latValue1 = latitude1.getLatitude();
			String latValue2 = latitude2.getLatitude();
			
			if (latValue1 == null && latValue2 == null)
			{
				return 0;
			}
			
			if(latValue2 == null)
			{
				return -1;
			}
			
			if(latValue1 == null)
			{
				return 1;
			}
			
			else return latValue1.compareTo(latValue2);
		}	
	};
	
	public static Comparator<City> LongitudeComparator = new Comparator<City>()
	{
		public int compare(City longitude1, City longitude2)
		{
			String longValue1 = longitude1.getLongitude();
			String longValue2 = longitude2.getLongitude();
			
			if(longValue1 == null && longValue2 == null )
			{
				return 0;
			}
			
			if(longValue2 == null)
			{
				return -1;
			}
			
			if(longValue1 == null)
			{
				return 1;
			}
			
			else return longValue1.compareTo(longValue2);	
		}	
	};
	
	public static Comparator<City> ElevationComparator = new Comparator<City>()
	{
		public int compare(City elevation1, City elevation2)
		{
			String elevationValue1 = elevation1.getElevation();
			String elevationValue2 = elevation2.getElevation();
			
			if (elevationValue1 == null && elevationValue2 == null)
			{
				return 0;
			}
			
			if (elevationValue2 == null)
			{
				return -1;
			}
			
			if (elevationValue1 == null)
			{
				return 1;
			}
			
			if (Integer.parseInt(elevationValue1) > Integer.parseInt(elevationValue2))
			{
				return -1;
			}
			
			if (Integer.parseInt(elevationValue1) < Integer.parseInt(elevationValue2))
			{
				return 1;
			}
			
			else return 0;
		}
	};	
	
	/**
	 * This constructor for Region class.
	 * @param name
	 * @param area
	 * @param population
	 */
	public Region(String name, String area, String population)
	{
		this.name = name;
		this.area = area;
		this.population = population;
	}
	
	public Region(String name, String area) 
	{
		this.name = name;
		this.area = area;
	}

	/**
	 * 
	 * @return name
	 */
	public String getName()
	{
		return name;
	}
	
	/**
	 * 
	 * @return population
	 */
	public String getPopulation()
	{
		return population;
	}
	
	/**
	 * 
	 * @return area
	 */
	public String getArea()
	{
		return area;
	}
	
	public int compareTo(Region compareRegion1) 
	{
		return name.compareTo(compareRegion1.name);	
	}
}