import java.io.Serializable;
import java.util.ArrayList;

/**
 * Project #5
 * CS 2334 Section 012
 * April 30, 2014
 * 
 * This is our super class for our Region MVC design. It contains a serialversionID and 
 * a name variable because all classes in project share these variables. 
 *
 */
public class Earth implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public String name;
	public String longitude;
	public String latitude;
	
	ArrayList<Point> pointList = new ArrayList<Point>();
	
	/**
	 * Constructor for ease of use
	 */
	public Earth()
	{
		
	}

	/**
	 * 
	 * @param name name of earth
	 */
	public Earth(String name)
	{
		this.name = name;
	}
	
	public Earth(String name, String latitude, String longitude)
	{
		this.name = name;
		this.latitude = latitude;
		this.longitude = longitude;
	}
	
	/**
	 * Getter method for name
	 * @return name of earth
	 */
	public String getName()
	{
		return name;
	}
	
	public String getLongitude()
	{
		return longitude;
	}
	
	public String getLatitude()
	{
		return latitude;
	}
	

	public void setName(String name)
	{
		this.name = name;
	}
	
	public void setLatitude(String latitude)
	{
		this.latitude = latitude;
	}
	
	public void setLongitude(String longitude)
	{
		this.longitude = longitude;
	}
}
