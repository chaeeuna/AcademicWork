import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;

import javax.swing.*;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;

/**
 * Project #5
 * CS 2334 Section 012
 * April 30, 2014
 * 
 *This is a class that creates each list for each region and implements all methods 
 *called by the Driver class. 
 * 
 */
public class RegionModel extends Earth
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private ArrayList<ActionListener> actionListenerList;
	ArrayList<Continent> continentList = new ArrayList<Continent>();
	ArrayList<Country> countryList = new ArrayList<Country>();
	ArrayList<City> cityList= new ArrayList<City>();
	ArrayList<City> cityDataExtended = new ArrayList<City>();
	ArrayList<Region> regionList = new ArrayList<Region>();
	ArrayList<Place> placeList = new ArrayList<Place>(); 
	ArrayList<Point> pointList = new ArrayList<Point>();
	ArrayList<Place> binaryList = new ArrayList<Place>();
	LinkedHashMap<String, Region> placeMap = new LinkedHashMap<String, Region>();
	
	ArrayList<Neighborhood> neighborhoodList = new ArrayList<Neighborhood>();	
	
	/**
	 * A simple constructor for easy method passing
	 */
	public RegionModel()
	{
	
	}
	
	public ArrayList<Continent> getContinentList()
	{
		return continentList;
	}
	
	public ArrayList<Country> getCountryList()
	{
		return countryList;
	}
	
	public ArrayList<City> getCityList()
	{
		return cityList;
	}
	
	public ArrayList<Place> getPlaceList()
	{
		return placeList;
	}
	
	public ArrayList<Point> getPointList()
	{
		return pointList;
	}
	
	public ArrayList<Neighborhood> getNeighborhoodList()
	{
		return neighborhoodList;
	}
	
	public void addContinentList(Continent newContinent)
	{
		this.continentList.add(newContinent);
		processEvent(new ActionEvent(this, ActionEvent.ACTION_PERFORMED, "add continent"));
	}
	
	public void addCountryList(Country newCountry)
	{
		this.countryList.add(newCountry);
		processEvent(new ActionEvent(this, ActionEvent.ACTION_PERFORMED, "add country"));
	}
	
	public void addCityList(City newCity)
	{
		this.cityList.add(newCity);
		processEvent(new ActionEvent(this, ActionEvent.ACTION_PERFORMED, "add city"));
	}
	
	public void addPlaceList(Place newPlace)
	{
		this.placeList.add(newPlace);
		processEvent(new ActionEvent(this, ActionEvent.ACTION_PERFORMED, "add place"));
	}
	
	public void addPointList(Point newPoint)
	{
		this.pointList.add(newPoint);
		processEvent(new ActionEvent(this, ActionEvent.ACTION_PERFORMED, "add point"));
	}
	
	public void addNeighborhoodList(Neighborhood newNeighborhood)
	{
		this.neighborhoodList.add(newNeighborhood);
		processEvent(new ActionEvent(this, ActionEvent.ACTION_PERFORMED, "add neighborhood"));
	}
	
	public void deleteContinentList(Continent continent)
	{
		this.continentList.remove(continent);
		processEvent(new ActionEvent(this, ActionEvent.ACTION_PERFORMED, "delete continent"));
	}
	
	public void deleteCountryList(Country country)
	{
		this.countryList.remove(country);
		processEvent(new ActionEvent(this, ActionEvent.ACTION_PERFORMED, "delete country"));
	}
	
	public void deleteCityList(City city)
	{
		this.cityList.remove(city);
		processEvent(new ActionEvent(this, ActionEvent.ACTION_PERFORMED, "delete city"));
	}
	
	public void deletePlaceList(Place place)
	{
		this.placeList.remove(place);
		processEvent(new ActionEvent(this, ActionEvent.ACTION_PERFORMED, "delete place"));
	}
	
	public void deletePointList(Point point)
	{
		this.pointList.remove(point);
		processEvent(new ActionEvent(this, ActionEvent.ACTION_PERFORMED, "delete point"));
	}
	
	public void importTextFile() throws IOException
	{
		if (continentList.size() == 0)
		{
			String textfile = new String(JOptionPane.showInputDialog("What is the name of the text file?" + "\n" + "*NOTE: Must contain continents*"));
			FileReader fr = new FileReader(textfile);
			BufferedReader br = new BufferedReader(fr);
			
			while(br.ready())
			{
				String nextLine = br.readLine();	 
				String[] data = nextLine.split(", ");
					
				if (data.length == 3)
				{
					String name = data[0];
					String population = data[1];
					String area = data[2];
						
					Continent newContinent = new Continent(name, population, area);
					addContinentList(newContinent);
				}		
			}
			
			br.close();
		}
		
		else if (countryList.size() == 0)
		{
			String textfile = JOptionPane.showInputDialog("What type list do you want to add?" +
					"\n" + "1 - Continent list" +
					"\n" + "2 - Country list");
			
			if (textfile.equals("1"))
			{
				textfile = new String(JOptionPane.showInputDialog("What is the name of the text file?" + "\n" + "*NOTE: Must contain CONTINENTS*"));
				writeContinentFile(textfile);
			}
			
			if (textfile.equals("2"))
			{
				textfile = new String(JOptionPane.showInputDialog("What is the name of the text file?" + "\n" + "*NOTE: Must contain COUNTRIES*"));
				writeCountryFile(textfile);
			}		
		}
		
		else if (cityList.size() == 0)
		{
			String textfile = JOptionPane.showInputDialog("What tpye list do you want to add?" +
														  "\n" + "1 - Continent list" +
														  "\n" + "2 - Country list" +
													      "\n" + "3 - City list");
			if (textfile.equals("1"))
			{
				textfile = new String(JOptionPane.showInputDialog("What is the name of the text file?" + "\n" + "*NOTE: Must contain CONTINENTS*"));
				writeContinentFile(textfile);

			}
			
			if (textfile.equals("2"))
			{
				textfile = new String(JOptionPane.showInputDialog("What is the name of the text file?" + "\n" + "*NOTE: Must contain COUNTRIES*"));
				writeCountryFile(textfile);
			}
			
			if (textfile.equals("3"))
			{
				textfile = new String(JOptionPane.showInputDialog("What is the name of the text file?" + "\n" + "*NOTE: Must contain CITIES*"));
				writeCityFile(textfile);
			}		
		}
		
		else if (placeList.size() == 0)
		{
			String textfile = JOptionPane.showInputDialog("What type list do you want to add?" +
														  "\n" + "1 - Continent list" +
														  "\n" + "2 - Country list" +
														  "\n" + "3 - City list" +
														  "\n" + "4 - Place List");
			if (textfile.equals("1"))
			{
				textfile = new String(JOptionPane.showInputDialog("What is the name of the text file?" + "\n" + "*NOTE: Must contain CONTINENTS*"));
				writeContinentFile(textfile);

			}
			
			if (textfile.equals("2"))
			{
				textfile = new String(JOptionPane.showInputDialog("What is the name of the text file?" + "\n" + "*NOTE: Must contain COUNTRIES*"));
				writeCountryFile(textfile);
			}
			
			if (textfile.equals("3"))
			{
				textfile = new String(JOptionPane.showInputDialog("What is the name of the text file?" + "\n" + "*NOTE: Must contain CITIES*"));
				writeCityFile(textfile);
			}
			
			if (textfile.equals("4"))
			{
				textfile = new String(JOptionPane.showInputDialog("What is the name of the text file?" + "\n" + "*NOTE: Must contain PLACES*"));
				writePlaceFile(textfile);	
			}
		}
		
		else 
		{
			String textfile = JOptionPane.showInputDialog("What type list do you want to add?" + "\n" + 
														  "1 - Continent list" + "\n" + 
														  "2 - Country list" + "\n" + 
														  "3 - City list" + "\n" + 
														  "4 - Place List" + "\n" + 
														  "5 - Point List");
			
			if (textfile.equals("1"))
			{
				textfile = new String(JOptionPane.showInputDialog("What is the name of the text file?" + "\n" + "*NOTE: Must contain CONTINENTS*"));
				writeContinentFile(textfile);
			}
			
			if (textfile.equals("2"))
			{
				textfile = new String(JOptionPane.showInputDialog("What is the name of the text file?" + "\n" + "*NOTE: Must contain COUNTRIES*"));
				writeCountryFile(textfile);
			}
			
			if (textfile.equals("3"))
			{
				textfile = new String(JOptionPane.showInputDialog("What is the name of the text file?" + "\n" + "*NOTE: Must contain CITIES*"));
				writeCityFile(textfile);
			}
			
			if  (textfile.equals("4"))
			{
				textfile = new String(JOptionPane.showInputDialog("What is the name of the text file?" + "\n" + "*NOTE: Must contain PLACES*"));
				writePlaceFile(textfile);	
			}
			
			if (textfile.equals("5"))
			{
				textfile = new String(JOptionPane.showInputDialog("What is the name of the text file?" + "\n" + "*NOTE: Must contain POINTS*"));
				writePointFile(textfile);	
			}
		}		
	}

	public void writeContinentFile(String textfile) throws IOException
	{
		FileReader fr = new FileReader(textfile);
		BufferedReader br = new BufferedReader(fr);
		
		while(br.ready())
		{
			String nextLine = br.readLine();	 
			String[] data = nextLine.split(", ");
				
			if (data.length == 3)
			{
				String name = data[0];
				String population = data[1];
				String area = data[2];
					
				Continent newContinent = new Continent(name, population, area);
				addContinentList(newContinent);
			}		
		}	
		
		br.close();
	}
	
	/**
	 * method to write country list to text file
	 * @param textfile
	 * @throws IOException
	 */
	public void writeCountryFile(String textfile) throws IOException
	{
		FileReader fr = new FileReader(textfile);
		BufferedReader br = new BufferedReader(fr);
		
		while (br.ready())
		{
			String nextLine = br.readLine();	 
			String[] data = nextLine.split(", ");
				
			if (data.length == 4)
			{
				String name = data[0];
				String population = data[1];
				String area = data[2];
				String continent = data[3];
					
				Country newCountry = new Country(name, population, area, continent);
				addCountryList(newCountry);
			}		
		}
		
		br.close();
	}
	
	/**
	 * A method to import city text file to list
	 * @param textfile
	 * @throws IOException
	 */
	public void writeCityFile(String textfile) throws IOException
	{
		FileReader fr = new FileReader(textfile);
		BufferedReader br = new BufferedReader(fr);
		
		while (br.ready())
		{
			String nextLine = br.readLine();	 
			String[] data = nextLine.split(", "); 
			
			if (data.length == 7)
			{
				String name = data[0];
				String area = data[1];
				String population = data[2];
				String country = data[3];
				String latitude = data[4];
				String longitude = data[5];
				String elevation = data[6];
					
				City newCity = new City(name, area, population, country, latitude, longitude, elevation);
				addCityList(newCity);
			}
			
			if (data.length == 4)
			{
				String name = data[0];
				String area = data[1];
				String population = data[2];
				String country = data[3];
					
				City newCity = new City(name, area, population, country);
				addCityList(newCity);
			}
		}	
		
		br.close();
	}
	
	private void writePlaceFile(String textfile) throws IOException 
	{
		FileReader fr = new FileReader(textfile);
		BufferedReader br = new BufferedReader(fr);
		
		while(br.ready())
		{
			String nextLine = br.readLine();	 
			String[] data = nextLine.split(", ");
			
			if (data.length == 4)
			{
				String name = data[0];
				String area = data[1];
				String population = data[2];
				String country = data[3];
					
				Place newPlace = new Place(name, area, population, country);
				addPlaceList(newPlace);
			}
			
			if (data.length > 4)
			{
				String name = data[0];
				String area = data[1];
				String type = data[2];
				String country = data[3];
				
				for (int i = 4; i < data.length; i++)
				{
					country += " " + data[i];
				}
				
				Place newPlace = new Place(name, area, type, country);
				addPlaceList(newPlace);
			}
		}	
		
		br.close();	
	}
	
	private void writePointFile(String textfile) throws IOException 
	{
		FileReader fr = new FileReader(textfile);
		BufferedReader br = new BufferedReader(fr);
		
		while(br.ready())
		{
			String nextLine = br.readLine();	 
			String[] data = nextLine.split(", ");
			
			if (data.length == 6)
			{
				String name = data[0];
				String type = data[1];
				String latitude = data[2];
				String longitude = data[3];
				String elevation = data[4];
				String region = data[5];
					
				Point newPoint = new Point(name, type, latitude, longitude, elevation, region);
				addPointList(newPoint);
			}
		}	
		
		br.close();
	}
	
	public void writeBinaryFile(ArrayList<?> regionList) throws IOException
	{
		if (regionList.get(0) instanceof Continent)
		{
			JOptionPane.showConfirmDialog(null, "Write to continents.obj?");
			FileOutputStream fileOutputStream = new FileOutputStream("continents.obj");
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
			objectOutputStream.writeObject(regionList);
			objectOutputStream.close();
		}
		
		if (regionList.get(0) instanceof Country)
		{
			JOptionPane.showConfirmDialog(null, "Write to countries.obj?");
			FileOutputStream fileOutputStream = new FileOutputStream("countries.obj");
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
			objectOutputStream.writeObject(regionList);
			objectOutputStream.close();
		}
		
		if (regionList.get(0) instanceof City)
		{
			JOptionPane.showConfirmDialog(null, "Write to cities.obj?");
			FileOutputStream fileOutputStream = new FileOutputStream("cities.obj");
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
			objectOutputStream.writeObject(regionList);
			objectOutputStream.close();
		}
		
		if (regionList.get(0) instanceof Place)
		{
			JOptionPane.showConfirmDialog(null, "Write to places.obj?");
			FileOutputStream fileOutputStream = new FileOutputStream("places.obj");
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
			objectOutputStream.writeObject(regionList);
			objectOutputStream.close();
		}
		
		if (regionList.get(0) instanceof Point)
		{
			JOptionPane.showConfirmDialog(null, "Write to points.obj?");
			FileOutputStream fileOutputStream = new FileOutputStream("points.obj");
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
			objectOutputStream.writeObject(regionList);
			objectOutputStream.close();
		}
	}
	
	public void writeTextFile() throws IOException
	{
		String choice = JOptionPane.showInputDialog("Enter ONE choice to write text file: " +
				"\n\n" + "1 - continent list" +
				"\n\n" + "2 - country list" +
				"\n\n" + "3 - city list" +
				"\n\n" + "4 - place list" +
				"\n\n" + "5 - point list");

		if (choice.equals("1"))
		{
			JOptionPane.showConfirmDialog(null, "Write Continent List to continents.txt?");
			FileWriter outfile = new FileWriter("continents.txt");
			BufferedWriter bw = new BufferedWriter(outfile);
			
			for (int i = 0; i < continentList.size(); i++)
			{
				bw.write(continentList.get(i).name + " " + 
						 continentList.get(i).area + " " +
						 continentList.get(i).population);
				bw.newLine();
			}
			
			bw.close();
		}
		
		if (choice.equals("2"))
		{
			JOptionPane.showConfirmDialog(null, "Write Country List to countries.txt?");
			FileWriter outfile = new FileWriter("countries.txt");
			BufferedWriter bw = new BufferedWriter(outfile);
			
			for(int i = 0; i < countryList.size(); i++)
			{
				bw.write(countryList.get(i).name + " " + 
						 countryList.get(i).area + " " +
						 countryList.get(i).population);
				bw.newLine();
			}
			
			bw.close();
		}
		
		if (choice.equals("3"))
		{
			JOptionPane.showConfirmDialog(null, "Write City List to cities.txt?");
			FileWriter outfile = new FileWriter("cities.txt");
			BufferedWriter bw = new BufferedWriter(outfile);
			
			for (int i = 0; i < cityList.size(); i++)
			{
				bw.write(cityList.get(i).name + " " + 
						 cityList.get(i).area + " " +
						 cityList.get(i).population + " " +
						 cityList.get(i).latitude + " "+ 
						 cityList.get(i).longitude + " " +
						 cityList.get(i).elevation);
				bw.newLine();
			}
			
			bw.close();
		}
		
		if (choice.equals("4"))
		{
			JOptionPane.showConfirmDialog(null, "Write Place List to places.txt?");
			FileWriter outfile = new FileWriter("places.txt");
			BufferedWriter bw = new BufferedWriter(outfile);
			
			for(int i = 0; i < placeList.size(); i++)
			{
				bw.write(placeList.get(i).name + " " + 
						 placeList.get(i).area + " " +
						 placeList.get(i).type + " " +
						 placeList.get(i).country);
				bw.newLine();
			}
			
			bw.close();
		}
		
		if (choice.equals("5"))
		{
			JOptionPane.showConfirmDialog(null, "Write Points List to points.txt?");
			FileWriter outfile = new FileWriter("points.txt");
			BufferedWriter bw = new BufferedWriter(outfile);
			
			for (int i = 0; i < pointList.size(); i++)
			{
				bw.write(pointList.get(i).name + " " + 
						 pointList.get(i).type + " " +
						 pointList.get(i).latitude + " " +
						 pointList.get(i).longitude + " " +
						 pointList.get(i).elevation + " " +
						 pointList.get(i).region);
				bw.newLine();
			}
			
			bw.close();
		}	
	}
	
	public void loadBinaryFile() throws IOException, ClassNotFoundException
	{
		String textfile = JOptionPane.showInputDialog("What binary list do you want to load?" +
													  "\n" + "1 - Continent list" +
													  "\n" + "2 - Country list" +
													  "\n" + "3 - City list" +
													  "\n" + "4 - Place List" +
													  "\n" + "5 - Point List");
		
		if (textfile.equals("1"))
		{
			String fileName = JOptionPane.showInputDialog("What is the name of the object file?");
			
			FileInputStream fileInputStream = new FileInputStream(fileName);
			ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
			ArrayList<Continent> continent = new ArrayList<Continent>();
			continent = (ArrayList<Continent>) objectInputStream.readObject();
			objectInputStream.close();
			
			for (int i=0; i<continent.size(); i++)
			{
				addContinentList(continent.get(i));
			}
		}
		
		if (textfile.equals("2"))
		{
			String fileName = JOptionPane.showInputDialog("What is the name of the object file?");
			
			FileInputStream fileInputStream = new FileInputStream(fileName);
			ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
			ArrayList<Country> country = new ArrayList<Country>();
			country = (ArrayList<Country>) objectInputStream.readObject();
			objectInputStream.close();
			
			for (int i=0; i<country.size(); i++)
			{
				addCountryList(country.get(i));
			}
		}
		
		if (textfile.equals("3"))
		{
			String fileName = JOptionPane.showInputDialog("What is the name of the object file?");
			
			FileInputStream fileInputStream = new FileInputStream(fileName);
			ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
			ArrayList<City> city = new ArrayList<City>();
			city = (ArrayList<City>) objectInputStream.readObject();
			objectInputStream.close();
			
			for (int i=0; i<city.size(); i++)
			{
				addCityList(city.get(i));
			}
		}
		
		if (textfile.equals("4"))
		{
			String fileName = JOptionPane.showInputDialog("What is the name of the object file?");
			
			FileInputStream fileInputStream = new FileInputStream(fileName);
			ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
			ArrayList<Place> place = new ArrayList<Place>();
			place = (ArrayList<Place>) objectInputStream.readObject();
			objectInputStream.close();
			
			for (int i=0; i<place.size(); i++)
			{
				addPlaceList(place.get(i));
			}
		}
		
		if (textfile.equals("5"))
		{
			String fileName = JOptionPane.showInputDialog("What is the name of the object file?");
			
			FileInputStream fileInputStream = new FileInputStream(fileName);
			ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
			ArrayList<Point> point = new ArrayList<Point>();
			point = (ArrayList<Point>) objectInputStream.readObject();
			objectInputStream.close();
			
			for (int i=0; i<point.size(); i++)
			{
				addPointList(point.get(i));
			}
		}
	}

	public ArrayList<Place> readBinaryFile(String binaryFilename) throws IOException, ClassNotFoundException
	{
		FileInputStream fileInputStream = new FileInputStream(binaryFilename);
		ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
		ArrayList<Place> regions = new ArrayList<Place>();
		regions = (ArrayList<Place>) objectInputStream.readObject();
		objectInputStream.close();
		return regions;
	}
	
	public void cityNeighFile() throws IOException
	{
		FileReader fr = new FileReader("cities.csv");
		BufferedReader br = new BufferedReader(fr);
		
		while(br.ready())
		{
			String nextLine = br.readLine();	 
			String[] data = nextLine.split(", ");
				
			if (data.length == 7)
			{
				String name = data[0];
				String latitude = data[4];
				String longitude = data[5];
					
				Neighborhood newNeighborhood = new Neighborhood(name, latitude, longitude);
				addNeighborhoodList(newNeighborhood);
			}		
		}
		br.close();
	}
	
	public void pointNeighFile() throws IOException
	{
		FileReader fr = new FileReader("points.csv");
		BufferedReader br = new BufferedReader(fr);
		
		while(br.ready())
		{
			String nextLine = br.readLine();	 
			String[] data = nextLine.split(", ");
				
			if (data.length == 6)
			{
				String name = data[0];
				String latitude = data[2];
				String longitude = data[3];
					
				Neighborhood newNeighborhood = new Neighborhood(name, latitude, longitude);
				addNeighborhoodList(newNeighborhood);
			}		
		}
		br.close();
	}
	
	/**
	 * This method requests user to select from a coordinate of regions.
	 * @throws IOException
	 */
	public void importNeighborhood() throws IOException
	{
		if (neighborhoodList.size() == 0)
		{
			String textfile = new String(JOptionPane.showInputDialog("What type list do you want to add?\n" +
																	 "3 - City list\n" + 
																     "5 - Point List\n" +
																     "6 - City and Point List"));
			
			if (textfile.equals("3"))
			{
				cityNeighFile();
			}
			else if (textfile.equals("5"))
			{
				pointNeighFile();
			}
			else
			{
				cityNeighFile();
				pointNeighFile();
			}	
		}	
	}

	public synchronized void addActionListener(ActionListener l) 
	{
		if (actionListenerList == null)
			actionListenerList = new ArrayList<ActionListener>();
		actionListenerList.add(l);
	}
	
	/**
	 * Remove an action event listener.
	 */
	public synchronized void removeActionListener(ActionListener l) {
		if (actionListenerList != null && actionListenerList.contains(l))
			actionListenerList.remove(l);
	}
	
	/**
	 * Fire event.
	 */
	private void processEvent(ActionEvent e) {
		ArrayList<ActionListener> list;
		
		synchronized (this) {
			if (actionListenerList == null) return;
			list = (ArrayList<ActionListener>)actionListenerList.clone();
		}
		
		for (int i = 0; i < list.size(); i++) {
			ActionListener listener = list.get(i);
			listener.actionPerformed(e);
		}
	}
}