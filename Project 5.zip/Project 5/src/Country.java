/**
 * Project #5
 * CS 2334 Section 012
 * April 30, 2014
 * 
 * This class abstracts the extracted data to store in multiple ways.
 * This class extends Region class and implements Comparable.  
 * It constructs the Country type.
 */
public class Country extends Region implements Comparable<Region>
{
	private static final long serialVersionUID = 1L;
	public String continent;

	/**
	 * 
	 * @param name
	 * @param population
	 * @param area
	 * @param continent
	 */
	public Country(String name, String population, String area, String continent)
	{
		super(name, area, population);
		this.continent = continent;
	}
	
	/**
	 * @return continent
	 */
	public String getContinent()
	{
		return continent;
	}
	
	/**
	 * @param obj
	 * @return
	 */
	public int compareTo(Country obj)
	{
		return name.compareTo(obj.name);
	}	
	
	public void setName(String name)
	{
		this.name = name;
	}
	
	public void setArea(String area)
	{
		this.area = area;
	}
	
	public void setPopulation(String population)
	{
		this.population = population;
	}
	
	public void setContinent(String continent)
	{
		this.continent = continent;
	}
}