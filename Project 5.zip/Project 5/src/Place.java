/**
 * Project #5
 * CS 2334 Section 012
 * April 30, 2014
 * 
 * Added class that constructs places of interest.
 * 
 */
public class Place extends Region implements Comparable<Region>
{
	private static final long serialVersionUID = 1L;
	String type;
	String country;
	
	/**
	 * A constructor that creates a place of interest object with type name and
	 * which country it is located
	 * 
	 * @param type type of place
	 * @param country country that PLace is in
	 */
	public Place(String name, String area, String type, String country)
	{
		super(name, area);
		this.type = type;
		this.country = country;
	}
	
	/**
	 * A getter method to get type of Place
	 * @return type of place
	 */
	public String getType()
	{
		return type;
	}
	
	/**
	 * A getter method to get country which place is in
	 * @return country name
	 */
	public String getCountry()
	{
		return country;
	}
	
	/**
	 * CompareTo method that is used by Collections.sort() to sort lexicographically
	 * @param obj Place object to be compared
	 * @return -1,0,1 depending on how Place object compared
	 */
	public int compareTo(Place obj)
	{
		return 0;
	}
	
	public void setName(String name)
	{
		this.name = name;
	}
	
	public void setArea(String area)
	{
		this.area = area;
	}
	
	public void setType(String type)
	{
		this.type = type;
	}
	
	public void setCountry(String country)
	{
		this.country = country;
	}
}