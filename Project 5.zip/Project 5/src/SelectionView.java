/**
 * Project #5
 * CS 2334 Section 012
 * April 30, 2014
 * 
 * This is our main selection view for our Region MVC design, this is where the lists
 * will be displayed and the user has options to edit the lists and output the lists. 
 *
 */

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.*;

public class SelectionView extends JFrame implements ActionListener{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	RegionModel model;
	RegionController controller;
	
	JFrame frame = new JFrame();
	JPanel listPanel = new JPanel(new GridLayout(1,6,10,10));
	JPanel buttonPanel = new JPanel(new GridLayout(1, 6, 5, 5));
	
	JMenuBar menuBar = new JMenuBar();
	
	JMenu fileMenu = new JMenu("File");
	JMenu graphMenu = new JMenu("Graph");
	JMenu neighborhoodMenu = new JMenu("Neighborhoods");
	
	JMenuItem itmSave = new JMenuItem("Save");
	JMenuItem itmLoad = new JMenuItem("Load");
	JMenuItem itmImport = new JMenuItem("Import");
	JMenuItem itmExport = new JMenuItem("Export");
	
	JMenuItem simpleBarMenu = new JMenu("Simple Bar");
	JMenuItem stackBarMenu = new JMenu("Stacked Bar");
	JMenuItem mapMenu = new JMenu("Map");
	JMenuItem simpleAreaMenu = new JMenu("Area");
	JMenuItem simplePopulationMenu = new JMenu("Population");
	JMenuItem stackAreaMenu = new JMenu("Area");
	JMenuItem stackPopulationMenu = new JMenu("Population");
	
	JMenuItem itmContinents = new JMenuItem("Continents");
	JMenuItem itmCountries = new JMenuItem("Countries");
	JMenuItem itmCities = new JMenuItem("Cities");
	JMenuItem itmPlace = new JMenuItem("Place");
	JMenuItem itmpopContinents = new JMenuItem("Continents");
	JMenuItem itmpopCountries = new JMenuItem("Countries");
	JMenuItem itmpopCities = new JMenuItem("Cities");
	JMenuItem itmpopPlace = new JMenuItem("Place");
	
	JMenuItem itmCountryCont = new JMenuItem("Countries within Continents");
	JMenuItem itmCityCount = new JMenuItem("Cities within Countries");
	JMenuItem itmPlacesCont = new JMenuItem("Places within Continents");
	JMenuItem itmPlacesCount = new JMenuItem("Places within Countries");
	JMenuItem itmPlacesCity = new JMenuItem("Places within Cities");
	
	JMenuItem itmpopCountryCont = new JMenuItem("Countries within Continents");
	JMenuItem itmpopCityCount = new JMenuItem("Cities within Countries");
	JMenuItem itmpopPlacesCont = new JMenuItem("Places within Continents");
	JMenuItem itmpopPlacesCount = new JMenuItem("Places within Countries");
	JMenuItem itmpopPlacesCity = new JMenuItem("Places within Cities");
	
	JMenuItem itmCityWorld = new JMenuItem("Cities Worldwide");
	JMenuItem itmCityCont = new JMenuItem("Cities within Continents");
	JMenuItem itmCityCountry = new JMenuItem("Cities within Countries");
	JMenuItem itmPointCity = new JMenuItem("Points within Cities");
	JMenuItem itmPointCount = new JMenuItem("Points within Countries");
	JMenuItem itmPointCont = new JMenuItem("Points within Continents");
	JMenuItem itmPointWorld = new JMenuItem("Points Worldwide");
	
	JMenuItem itmNeighborhoodList = new JMenuItem("Neighborhood List");
	JMenuItem itmRecNeighborhoodList = new JMenuItem("Recursive Neighborhood List");
	JMenuItem itmNeighborhoodCheck = new JMenuItem("Geographic Neighborhood Check");
	JMenuItem itmNeighborhoodMap = new JMenuItem("Geographic Neighborhood");
	
	JButton jbtContAdd = new JButton("Add");
	JButton jbtContEdit = new JButton("Edit");
	JButton jbtContDelete = new JButton("Delete");
	
	JButton jbtCountAdd = new JButton("Add");
	JButton jbtCountEdit = new JButton("Edit");
	JButton jbtCountDelete = new JButton("Delete");
	
	JButton jbtCityAdd = new JButton("Add");
	JButton jbtCityEdit = new JButton("Edit");
	JButton jbtCityDelete = new JButton("Delete");
	
	JButton jbtPlaceAdd = new JButton("Add");
	JButton jbtPlaceEdit = new JButton("Edit");
	JButton jbtPlaceDelete = new JButton("Delete");
	
	JButton jbtPointAdd = new JButton("Add");
	JButton jbtPointEdit = new JButton("Edit");
	JButton jbtPointDelete = new JButton("Delete");
	
	JButton jbtBreadth = new JButton("Breadth");
	JButton jbtLength = new JButton("Length");
	JButton jbtLatLong = new JButton("LatLong");
	
	JList contList;
	JList countList;
	JList cityList;
	JList placeList;
	JList pointList;
	JList neighborhoodList;
	
	JPanel contButtons = new JPanel(new BorderLayout());
	JPanel countButtons = new JPanel(new BorderLayout());
	JPanel cityButtons = new JPanel(new BorderLayout());
	JPanel placeButtons = new JPanel(new BorderLayout());
	JPanel pointButtons = new JPanel(new BorderLayout());
	JPanel neighButtons = new JPanel(new BorderLayout());
	
	public SelectionView()
	{
		setLayout(new BorderLayout(5,10));
		add(menuBar, BorderLayout.NORTH);
		add(listPanel, BorderLayout.CENTER);
		add(buttonPanel, BorderLayout.SOUTH);
		
		fileMenu.add(itmSave); 
		fileMenu.add(itmLoad); 
		fileMenu.add(itmImport); 
		fileMenu.add(itmExport);
		
		simpleAreaMenu.add(itmContinents);
		simpleAreaMenu.add(itmCountries);
		simpleAreaMenu.add(itmCities);
		simpleAreaMenu.add(itmPlace);

		simplePopulationMenu.add(itmpopContinents);
		simplePopulationMenu.add(itmpopCountries);
		simplePopulationMenu.add(itmpopCities);
		simplePopulationMenu.add(itmpopPlace);
		
		simpleBarMenu.add(simpleAreaMenu);
		simpleBarMenu.add(simplePopulationMenu);
		
		//--------------------------------------------
		
		stackAreaMenu.add(itmCountryCont);
		stackAreaMenu.add(itmCityCount);
		stackAreaMenu.add(itmPlacesCont);
		stackAreaMenu.add(itmPlacesCount);
		stackAreaMenu.add(itmPlacesCity);

		stackPopulationMenu.add(itmpopCountryCont);
		stackPopulationMenu.add(itmpopCityCount);
		stackPopulationMenu.add(itmpopPlacesCont);
		stackPopulationMenu.add(itmpopPlacesCount);
		stackPopulationMenu.add(itmpopPlacesCity);
		
		stackBarMenu.add(stackAreaMenu);
		stackBarMenu.add(stackPopulationMenu);
		
		//---------------------------------------------
		
		mapMenu.add(itmCityCountry);
		mapMenu.add(itmCityCont);
		mapMenu.add(itmCityWorld);
		mapMenu.add(itmPointCity);
		mapMenu.add(itmPointCount);
		mapMenu.add(itmPointCont);
		mapMenu.add(itmPointWorld);
		
		graphMenu.add(simpleBarMenu);
		graphMenu.add(stackBarMenu);
		graphMenu.add(mapMenu);
		graphMenu.add(itmNeighborhoodMap);
		
		neighborhoodMenu.add(itmNeighborhoodList);
		neighborhoodMenu.add(itmRecNeighborhoodList);
		neighborhoodMenu.add(itmNeighborhoodCheck);
		
		menuBar.add(fileMenu);
		menuBar.add(graphMenu);
		menuBar.add(neighborhoodMenu);
		
		contButtons.add(jbtContAdd, BorderLayout.NORTH);
		contButtons.add(jbtContEdit, BorderLayout.CENTER);
		contButtons.add(jbtContDelete, BorderLayout.SOUTH);
		
		countButtons.add(jbtCountAdd, BorderLayout.NORTH);
		countButtons.add(jbtCountEdit, BorderLayout.CENTER);
		countButtons.add(jbtCountDelete, BorderLayout.SOUTH);
		
		cityButtons.add(jbtCityAdd, BorderLayout.NORTH);
		cityButtons.add(jbtCityEdit, BorderLayout.CENTER);
		cityButtons.add(jbtCityDelete, BorderLayout.SOUTH);
		
		placeButtons.add(jbtPlaceAdd, BorderLayout.NORTH);
		placeButtons.add(jbtPlaceEdit, BorderLayout.CENTER);
		placeButtons.add(jbtPlaceDelete, BorderLayout.SOUTH);
		
		pointButtons.add(jbtPointAdd, BorderLayout.NORTH);
		pointButtons.add(jbtPointEdit, BorderLayout.CENTER);
		pointButtons.add(jbtPointDelete, BorderLayout.SOUTH);
		
		neighButtons.add(jbtBreadth, BorderLayout.NORTH);
		neighButtons.add(jbtLength, BorderLayout.CENTER);
		neighButtons.add(jbtLatLong, BorderLayout.SOUTH);
		
		buttonPanel.add(contButtons);
		buttonPanel.add(countButtons);
		buttonPanel.add(cityButtons);
		buttonPanel.add(placeButtons);
		buttonPanel.add(pointButtons);
		buttonPanel.add(neighButtons);
	}

	public void actionPerformed(ActionEvent e) 
	{
		if (e.getActionCommand().equals("add continent"))
		{
			contList.setListData(model.getContinentList().toArray());	
			setVisible(true);
		}
		
		if (e.getActionCommand().equals("add country"))
		{
			countList.setListData(model.getCountryList().toArray());	
			setVisible(true);
		}
		
		if (e.getActionCommand().equals("add city"))
		{
			cityList.setListData(model.getCityList().toArray());	
			setVisible(true);
		}
		
		if (e.getActionCommand().equals("add place")){
			
			placeList.setListData(model.getPlaceList().toArray());	
			setVisible(true);
		}
		
		if (e.getActionCommand().equals("add point"))
		{
			pointList.setListData(model.getPointList().toArray());	
			setVisible(true);
		}
		
		if (e.getActionCommand().equals("add neighborhood"))
		{
			neighborhoodList.setListData(model.getNeighborhoodList().toArray());	
			setVisible(true);
		}
		
		if (e.getActionCommand().equals("delete continent"))
		{
			contList.setListData(model.getContinentList().toArray());	
			setVisible(true);
		}
		
		if (e.getActionCommand().equals("delete country"))
		{
			countList.setListData(model.getCountryList().toArray());	
			setVisible(true);
		}
		
		if (e.getActionCommand().equals("delete city"))
		{
			cityList.setListData(model.getCityList().toArray());	
			setVisible(true);
		}
		
		if (e.getActionCommand().equals("delete place"))
		{
			placeList.setListData(model.getPlaceList().toArray());	
			setVisible(true);
		}
		
		if (e.getActionCommand().equals("delete point"))
		{
			pointList.setListData(model.getPlaceList().toArray());	
			setVisible(true);
		}	
	}
	
	public void setModel(RegionModel model, SelectionView view) 
	{
		this.model = model;
		if (this.model != null)
		{
			model.addActionListener(this);
			
			contList = new JList(model.getContinentList().toArray());
			countList = new JList(model.getCountryList().toArray());
			cityList = new JList(model.getCityList().toArray());
			placeList = new JList(model.getPlaceList().toArray());
			pointList = new JList(model.getPointList().toArray());
			neighborhoodList = new JList(model.getNeighborhoodList().toArray());
			
			JScrollPane contPane = new JScrollPane(contList);
			JScrollPane countPane = new JScrollPane(countList);
			JScrollPane cityPane = new JScrollPane(cityList);
			JScrollPane placePane = new JScrollPane(placeList);
			JScrollPane pointPane = new JScrollPane(pointList);
			JScrollPane neighPane = new JScrollPane(neighborhoodList);
			
			listPanel.add(contPane);
			listPanel.add(countPane);
			listPanel.add(cityPane);
			listPanel.add(placePane);
			listPanel.add(pointPane);
			listPanel.add(neighPane);
		}
		
		frame = view;
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(1000,600);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}
	
	public JMenuItem getImportItem() {return itmImport;}
	public JMenuItem getExportItem() {return itmExport;}
	public JMenuItem getSaveItem() {return itmSave;}
	public JMenuItem getLoadItem() {return itmLoad;}
	
	public JMenuItem getContItem() {return itmContinents;}
	public JMenuItem getCountItem(){return itmCountries;}
	public JMenuItem getCityItem() {return itmCities;}
	public JMenuItem getPlaceItem() {return itmPlace;}
	
	public JButton getContAddButton() {return jbtContAdd;}
	public JButton getCountAddButton() {return jbtCountAdd;}
	public JButton getCityAddButton() {return jbtCityAdd;}
	public JButton getPlaceAddButton() {return jbtPlaceAdd;}
	public JButton getPointAddButton(){return jbtPointAdd;}
	
	public JMenuItem getContPopItem() {return itmpopContinents;}
	public JMenuItem getCountPopItem(){return itmpopCountries;}
	public JMenuItem getCityPopItem() {return itmpopCities;}
	public JMenuItem getPlacePopItem() {return itmpopPlace;}
	
	public JButton getContEditButton() {return jbtContEdit;}
	public JButton getCountEditButton() {return jbtCountEdit;}
	public JButton getCityEditButton() {return jbtCityEdit;}
	public JButton getPlaceEditButton() {return jbtPlaceEdit;}
	public JButton getPointEditButton() {return jbtPointEdit;}

	public JButton getContDeleteButton() {return jbtContDelete;}
	public JButton getCountDeleteButton() {return jbtCountDelete;}
	public JButton getCityDeleteButton() {return jbtCityDelete;}
	public JButton getPlaceDeleteButton(){return jbtPlaceDelete;}
	public JButton getPointDeleteButton() {return jbtPointDelete;}
	
	public JButton getBreadthButton() {return jbtBreadth;}
	public JButton getLengthButton() {return jbtLength;}
	public JButton getLatLongButton() {return jbtLatLong;}
	
	public JMenuItem getItmCountryCont() {return itmCountryCont;}
	public JMenuItem getItmCityCountry() {return itmCityCount;}
	public JMenuItem getItmPlacesCont() {return itmPlacesCont;}
	public JMenuItem getItmPlacesCount() {return itmPlacesCount;}
	public JMenuItem getItmPlacesCity() {return itmPlacesCity;}
	
	public JMenuItem getItmPopCountryCont() {return itmpopCountryCont;}
	public JMenuItem getItmPopCityCountry() {return itmpopCityCount;}
	public JMenuItem getItmPopPlacesCont() {return itmpopPlacesCont;}
	public JMenuItem getItmPopPlacesCount(){return itmpopPlacesCount;}
	public JMenuItem getItmPopPlacesCity() {return itmpopPlacesCity;}
	
	public JMenuItem getItmCityWorld() {return itmCityWorld;}
	public JMenuItem getItmCityCont() {return itmCityCont;}
	public JMenuItem getItmCityCount() {return itmCityCount;}
	public JMenuItem getItmPointCity() {return itmPointCity;}
	public JMenuItem getItmPointCount() {return itmPointCount;}
	public JMenuItem getItmPointCont() {return itmPointCont;}
	public JMenuItem getItmPointWorld() {return itmPointWorld;}
	
	public JMenuItem getNeighborhoodList() {return itmNeighborhoodList;}
	public JMenuItem getRecNeighborhoodList() {return itmRecNeighborhoodList;}
	public JMenuItem getNeighborhoodCheck() {return itmNeighborhoodCheck;}
	public JMenuItem getNeighborhoodMap() {return itmNeighborhoodMap;}
}