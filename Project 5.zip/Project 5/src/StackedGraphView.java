/**
 * Project #5
 * CS 2334 Section 012
 * April 30, 2014
 * 
 * ************ Some code was taken from the textbook site****************
 * 
 * This is the class that displays a single bar composed of several smaller segments as the bar chart.
 * 
 */

import javax.swing.*;

import java.awt.*;

public class StackedGraphView extends JPanel  
{	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long[] data;
	private String[] names;
	
	RegionModel model;
	/**
	 * Constructor for ease of use
	 */
	public StackedGraphView()
	{
		
	}
	
	public void setModel(RegionModel model, StackedGraphView view)
	{	
		this.model = model;
	}
	/**This method calls on the repaint component so that every time there is a change to the view window 
	 * the graph is redrawn on the view panel. 
	 * 
	 * @param data data this is the area property of the specified region to be plotted on single bar
	 * @param names names these are the names of each region to be used as labels under each bar in the bar graph
	 */
	public void showHistogram(long[] data, String[] names)
	{
		this.names = names;
		this.data = data;
		repaint();
	}
	
	/**
	 * This is the overriden method that JPanel uses to paint all components.
	 */
	protected void paintComponent(Graphics g)
	{
		if(data == null) return;
		
		super.paintComponent(g);
		
		int width = getWidth();
		int height = getHeight();
		int total = 0;
		int bottom = 0;
		
		for (int i = 0; i<data.length; i++)
		{
			total += data[i];
		}
		
		g.drawLine(10,  height - 20,  width - 10,  height - 20);
		
		for (int i = 0; i < data.length; i++)
		{
			//find bar height
			int barHeight = (int) (((data[i])*height)/total);
			bottom += barHeight;
					
			//display a bar 
			g.drawRect(width/3, height - 20 - bottom, width/3, barHeight);
			
			//display bar labels
			g.drawString(" " +names[i] + " - " + data[i], width/3 , height - 5 - bottom);			
		}	
	}
}