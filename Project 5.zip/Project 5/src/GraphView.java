/**
 * Project #5
 * CS 2334 Section 012
 * April 30, 2014
 * 
 * ************ Some code was taken from the textbook site****************
 * 
 * This is a class that creates a graphical display for the user when
 * GD is the option chosen.
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class GraphView extends JPanel  
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long[] data;
	private String[] names;
	RegionModel model;
	RegionController controller;
	
	/**
	 * Constructor for ease of use
	 */
	public GraphView()
	{
		
	}

	public void setModel(RegionModel model, GraphView view)
	{	
		this.model = model;
	}

	/**
	 * This method calls on the repaint component so that every time there is a change to the view window 
	 * the graph is redrawn on the view panel. 
	 * 
	 * @param data this is the properties of the specified region (area or population) to be plotted on bar graph
	 * @param names these are the names of each region to be used as labels under each bar in the bar graph
	 */
	public void showHistogram(long[] data, String[] names)
	{
		this.names = names;
		this.data = data;
		repaint();
	}
	
	/**
	 * This is the overriden method that JPanel uses to paint all components.
	 */
	protected void paintComponent(Graphics g)
	{
		if(data == null) return;
		
		super.paintComponent(g);
		
		int width = getWidth(); //getting width of frame
		int height = getHeight(); //getting height of frame
		int sections = (2*data.length)+1;
		
		long maxCount = 0;
		for(int i =0; i < data.length; i++)
		{
		     if (maxCount < data[i])
		         maxCount = data[i];
		}

		long minCount = maxCount;
		for(int i =0; i < data.length; i++)
		{
		     if (minCount > data[i])
		         minCount = data[i];
		}

		//draws the bottom line
		g.drawLine(10,  height - 20,  width - 10,  height - 20);
		
		int k = 1;
		
		for (int i = 0; i < data.length; i++)
		{
			//find bar height
			int barHeight = (int) (data[i]/((maxCount-minCount)/height));
			int x = (width*k)/sections;
			
			//display a bar 
			g.drawRect(x, height - 20 - barHeight, width/sections, barHeight);
			
			//display bar labels
			g.drawString(names[i], x, height - 5);
			
			k += 2;
		}
	}
}