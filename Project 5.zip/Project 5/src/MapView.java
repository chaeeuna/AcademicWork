/**
 * Project #5
 * CS 2334 Section 012
 * April 30, 2014
 * 
 ************* Some code was taken from the textbook site****************
 * 
 * This class uses a map image from a local file(obtained from web) and will display this plate carree
 * map projection of the world with points plotted on it for all of the cities, and the selected data. 
 * 
 */
import java.awt.*;
import java.awt.event.ActionEvent;

import javax.swing.*;

public class MapView extends JPanel
{
	RegionModel model;
	double[] latitude;
	double[] longitude;
	private static final long serialVersionUID = 1L;

	/**
	 * Constructor for ease of use
	 */
	public MapView() 
	{
		
	}
	
	public void setModel(RegionModel model, MapView view)
	{	
		this.model = model;
	}

	/**
	 * This method uses repaint() to call paintComponent method to draw all panel components
	 * every time the view panel is modified. 
	 * 
	 * @param latData this is the array of latitude values
	 * @param longData this is the array of longitude values
	 */
	public void showMap(double[] latData, double[] longData)
	{
		this.latitude = latData;
		this.longitude = longData;
		repaint();
	}
	
	private ImageIcon imageIcon = new ImageIcon("worldMap.jpg");
	private Image image = imageIcon.getImage();

	/**
	 * The overriden paintComponent(0 that JPanel uses to draw all components specified
	 */
	protected void paintComponent(Graphics g) 
	{
		super.paintComponent(g);
		
		double height = (double)getHeight();
		double width = (double)getWidth();
		
		if (image != null)
		g.drawImage(image, 0, 0, getWidth(), getHeight(), this);
		
		double x=0;
		double y=0;
		
		for(int i = 0; i < longitude.length; i++)
		{
			 x = ((((longitude[i]/360.0)*100.0)*width)/100.0);
			 y = (((((latitude[i]/180.0)*100.0))*height)/100.0);
			 g.fillOval((int)x,(int)y, 10, 10);
		}
	}
}