/**
 * Project #5
 * CS 2334 Section 012
 * April 30, 2014
 * 
 * This class executes all the methods.
 */

import java.io.*;
import javax.swing.*;

public class Driver
{
	static RegionModel model;
	static RegionController controller = new RegionController();
	static SelectionView view = new SelectionView();
	static GraphView barGraph = new GraphView();
	static MapView map = new MapView();
	
	/**
	 * 
	 * @param args
	 * @throws ClassNotFoundException 
	 * @throws IOExceptions
	 */
	public static void main(String[] args) 
	{
		model = new RegionModel();
		view.setModel(model,view);
		barGraph.setModel(model, barGraph);
		map.setModel(model, map);
		controller.setModel(model);
		controller.setInputWindow(view);
	}
}