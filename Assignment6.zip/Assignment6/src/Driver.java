/**
 * 
 * Some code were referenced a textbook:
 * Introduction to Java Programming, 10th Edition
 * By Y. Daniel Liang
 * http://www.cs.armstrong.edu/liang/intro10e/html/MultipleBounceBall.html
 * 
 */

import java.awt.Dialog;
import javax.swing.JOptionPane;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;

public class Driver extends Application 
{
	TargetPane targetPane = new TargetPane();
	int count;
	
	public void start(Stage primaryStage) 
	{
		// Create button and place on a horizontal box.
		HBox hBox = new HBox(10);
		Button addButton1 = new Button("Add Target 1");
		Button addButton2 = new Button("Add Target 2");;
		
		
		// Link the add method to the target pane.
		addButton1.setOnAction(e -> targetPane.addTarget1());
		addButton2.setOnAction(e -> targetPane.addTarget2());

		hBox.getChildren().addAll(addButton1, addButton2);
		hBox.setAlignment(Pos.TOP_LEFT);

		// Place both target pane and box on a main frame.
		BorderPane pane = new BorderPane();
		pane.setCenter(targetPane);
		pane.setBottom(hBox);
		
		// Title bar, window size, set stage visible
		primaryStage.setTitle("Fitt's Law Test");
		primaryStage.setScene(new Scene(pane, 800, 600));
		primaryStage.show();
	}

	public static void main(String[] args) 
	{
		launch(args);
	}
}