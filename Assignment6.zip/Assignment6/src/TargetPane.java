import javax.swing.JOptionPane;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.util.Duration;

public class TargetPane extends Pane 
{
	String s = JOptionPane.showInputDialog("Enter count: ");
	int count = Integer.parseInt(s);
	
	double[] times = new double[count];
	double[] indexes = new double[count];
	
    public Timeline animation;
    Target target1 = new Target(30, 30, 30, Color.LIGHTBLUE);
    Target target2 = new Target(30, 30, 30, Color.LIGHTGRAY);
    
    double a,b;
    double centerX1;
    double centerY1;
    double centerX2;
    double centerY2;
    
    double distanceX;
    double distanceY;
    
    long time1;
    long time2;
    
    double distance;
    double time;
    double width;
    double index;

    public TargetPane() 
    {
    	// Create an animation for the target
    	animation = new Timeline(
		  	  new KeyFrame(Duration.millis(8), 
		  			       e -> moveTarget()));
    	animation.setCycleCount(Timeline.INDEFINITE);
    	animation.play(); // Start animation
    }

    public void addTarget1() 
    {
    	getChildren().addAll(target1);	
    	target1.setOnMousePressed(new EventHandler<MouseEvent>()
		{
			public void handle(MouseEvent event) 
			{
				centerX1 = target1.getCenterX();
				centerY1 = target2.getCenterY();
				time1 = System.currentTimeMillis();
			}
		});
    }
     	 
    public void addTarget2() 
    {
		getChildren().addAll(target2);
		target2.setOnMousePressed(new EventHandler<MouseEvent>()
		{
			public void handle(MouseEvent event) 
			{
				centerX2 = target2.getCenterX();
				centerY2 = target2.getCenterY();
				time2 = System.currentTimeMillis();

				getDistance();
				getTime();
				getAWidth();
				getIndex();
				
				System.out.println("\nCount: " + count);
				System.out.println("Distance: " + distance + " pixels");
				System.out.println("Time: " + time + " ms");
				System.out.println("Width: " + width + " pixels");
				System.out.println("Index of difficulty: " + index);
				
				times[count-1] = time;
				indexes[count-1] = index;
				
				count--;
				
				if (count < 1)
				{
					animation.stop();
					Graph g = new Graph(indexes, times);
					a = g.intercept();
					b = g.slope();
					System.out.println("a = " + a + " b = " +b);					
				}
			}
		});	
    }

    public double getDistance()
    {
    	distanceX = centerX1 - centerX2;
    	distanceY = centerY1 - centerY2;
    	distance = Math.sqrt(Math.pow(distanceX, 2) + Math.pow(distanceY, 2));
    	distance = Math.round(distance);
		return distance;
    }
    
    public double getTime()
    {
    	time = time2 - time1;
    	time = Math.round(time);
    	return time;
    }
    
    public double getAWidth()
    {
    	width = target2.getLayoutBounds().getWidth();
    	return width;    	
    }
    
    public double getIndex()
    {
    	index = distance/width + 1;
    	index = Math.log(index)/Math.log(2.0);
		return index;
    }

    protected void moveTarget() 
    {
    	for (Node node: this.getChildren()) 
    	{
    		Target target = (Target)node;
        
    		// Check x boundaries
    		if (target.getCenterX() < target.getRadius() || 
        	target.getCenterX() > getWidth() - target.getRadius()) 
    		{
    			// Change x direction of the target
    			target.boundaryX *= -1; 
    		}
    		
    		// Check y boundaries.
    		if (target.getCenterY() < target.getRadius() || 
        	target.getCenterY() > getHeight() - target.getRadius()) 
    		{
    			// Change y direction of the target
    			target.boundaryY *= -1;
    		}
        
        // Adjust target position
        target.setCenterX(target.boundaryX + target.getCenterX());
        target.setCenterY(target.boundaryY + target.getCenterY());
      }
    }
	public int getCount(){
		return count;
	}
}