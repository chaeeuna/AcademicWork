import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

public  class Target extends Circle
{
	double boundaryX = 1;
	double boundaryY = 1;
	
	Target(double x, double y, double r, Color color)
	{
		super(x, y, r);
		setFill(color);
	}
}
